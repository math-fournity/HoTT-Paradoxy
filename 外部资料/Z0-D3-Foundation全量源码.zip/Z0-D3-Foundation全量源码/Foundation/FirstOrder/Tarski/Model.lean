module
public import Foundation.FirstOrder.Tarski.Operator
public import Foundation.FirstOrder.Tarski.Elementary
@[expose] public section
set_option autoImplicit true

namespace FFL

namespace FirstOrder

universe u u₁ u₂ v v'

namespace Tarski.Structure

structure Model (L : Language) (M : Type*) where
  intro : M

namespace Model

variable [Tarski.Structure L M]

def equiv (L : Language) (M : Type*) : M ≃ Model L M where
  toFun := fun x => ⟨x⟩
  invFun := Model.intro
  left_inv := by intro x; simp
  right_inv := by rintro ⟨x⟩; simp

instance : Tarski.Structure L (Model L M) := Tarski.Structure.ofEquiv (equiv L M)

instance [h : Nonempty M] : Nonempty (Model L M) := by
  rcases h with ⟨x⟩; exact ⟨equiv L M x⟩

instance elementaryEquiv (L : Language) (M : Type*) [Nonempty M] [Tarski.Structure L M] :
    M ≡ₑ[L] Model L M :=
  ElementaryEquiv.ofEquiv _

section

open Semiterm Semiformula

instance [Operator.Zero L] : Zero (Model L M) := ⟨(@Operator.Zero.zero L _).val ![]⟩

instance [Operator.Zero L] : Tarski.Structure.Zero L (Model L M) := ⟨rfl⟩

instance [Operator.One L] : One (Model L M) := ⟨(@Operator.One.one L _).val ![]⟩

instance [Operator.One L] : Tarski.Structure.One L (Model L M) := ⟨rfl⟩

instance [Operator.Add L] : Add (Model L M) :=
  ⟨fun x y => (@Operator.Add.add L _).val ![x, y]⟩

instance [Operator.Add L] : Tarski.Structure.Add L (Model L M) := ⟨fun _ _ => rfl⟩

instance [Operator.Mul L] : Mul (Model L M) :=
  ⟨fun x y => (@Operator.Mul.mul L _).val ![x, y]⟩

instance [Operator.Mul L] : Tarski.Structure.Mul L (Model L M) := ⟨fun _ _ => rfl⟩

instance [Operator.Exp L] : Exp (Model L M) :=
  ⟨fun x => (@Operator.Exp.exp L _).val ![x]⟩

instance [Operator.Exp L] : Tarski.Structure.Exp L (Model L M) := ⟨fun _ => rfl⟩

instance [Operator.Eq L] [Tarski.Structure.Eq L M] : Tarski.Structure.Eq L (Model L M) :=
  ⟨fun x y => by simp [operator_val_ofEquiv_iff]⟩

instance [Operator.LT L] : LT (Model L M) :=
  ⟨fun x y => (@Operator.LT.lt L _).val ![x, y]⟩

instance [Operator.LT L] : Tarski.Structure.LT L (Model L M) := ⟨fun _ _ => iff_of_eq rfl⟩

instance [Operator.Mem L] : Membership (Model L M) (Model L M) :=
  ⟨fun x y => (@Operator.Mem.mem L _).val ![y, x]⟩

instance [Operator.Mem L] : Tarski.Structure.Mem L (Model L M) := ⟨fun _ _ => iff_of_eq rfl⟩

end

end Model

section ofFunc

variable (F : ℕ → Type*) {M : Type*} (fF : {k : ℕ} → (f : F k) → (Fin k → M) → M)

abbrev ofFunc : Tarski.Structure (Language.ofFunc F) M where
  func := fun _ f v => fF f v
  rel  := fun _ r _ => r.elim

lemma func_ofFunc {k} (f : F k) (v : Fin k → M) : (ofFunc F fF).func f v = fF f v := rfl

end ofFunc

section add

variable (L₁ : Language.{u₁}) (L₂ : Language.{u₂}) (M : Type*) [str₁ : Tarski.Structure L₁ M]
    [str₂ : Tarski.Structure L₂ M]

instance add : Tarski.Structure (L₁.add L₂) M where
  func := fun _ f v =>
    match f with
    | Sum.inl f => func f v
    | Sum.inr f => func f v
  rel := fun _ r v =>
    match r with
    | Sum.inl r => rel r v
    | Sum.inr r => rel r v

variable {L₁ L₂ M}

@[simp] lemma func_sigma_inl {k} (f : L₁.Func k) (v : Fin k → M) :
    (add L₁ L₂ M).func (Sum.inl f) v = func f v := rfl

@[simp] lemma func_sigma_inr {k} (f : L₂.Func k) (v : Fin k → M) :
    (add L₁ L₂ M).func (Sum.inr f) v = func f v := rfl

@[simp] lemma rel_sigma_inl {k} (r : L₁.Rel k) (v : Fin k → M) :
    (add L₁ L₂ M).rel (Sum.inl r) v ↔ rel r v := iff_of_eq rfl

@[simp] lemma rel_sigma_inr {k} (r : L₂.Rel k) (v : Fin k → M) :
    (add L₁ L₂ M).rel (Sum.inr r) v ↔ rel r v := iff_of_eq rfl

lemma lMap_add₁ : (add L₁ L₂ M).lMap (Language.Hom.add₁ L₁ L₂) = str₁ := rfl

lemma lMap_add₂ : (add L₁ L₂ M).lMap (Language.Hom.add₂ L₁ L₂) = str₂ := rfl

@[simp] lemma val_lMap_add₁ {n} (t : Semiterm L₁ μ n) (e : Fin n → M) (f : μ → M) :
    Semiterm.val (s := add L₁ L₂ M) e f (t.lMap (Language.Hom.add₁ L₁ L₂)) =
        t.val (s := str₁) e f := by
  rw [Semiterm.val_lMap, lMap_add₁]

@[simp] lemma val_lMap_add₂ {n} (t : Semiterm L₂ μ n) (e : Fin n → M) (f : μ → M) :
    Semiterm.val (s := add L₁ L₂ M) e f (t.lMap (Language.Hom.add₂ L₁ L₂)) =
        t.val (s := str₂) e f := by
  rw [Semiterm.val_lMap, lMap_add₂]

@[simp] lemma eval_lMap_add₁ {n} (φ : Semiformula L₁ μ n) (e : Fin n → M) (f : μ → M) :
    (Semiformula.lMap (Language.Hom.add₁ L₁ L₂) φ).Eval (s := add L₁ L₂ M) e f
    ↔ φ.Eval (s := str₁) e f := by
  rw [Semiformula.eval_lMap, lMap_add₁]

@[simp] lemma eval_lMap_add₂ {n} (φ : Semiformula L₂ μ n) (e : Fin n → M) (f : μ → M) :
    (Semiformula.lMap (Language.Hom.add₂ L₁ L₂) φ).Eval (s := add L₁ L₂ M) e f
    ↔ φ.Eval (s := str₂) e f := by
  rw [Semiformula.eval_lMap, lMap_add₂]

end add

section sigma

variable (L : ι → Language) (M : Type*) [str : (i : ι) → Tarski.Structure (L i) M]

instance sigma : Tarski.Structure (Language.sigma L) M where
  func := fun _ ⟨_, f⟩ v ↦ func f v
  rel  := fun _ ⟨_, r⟩ v ↦ rel r v

@[simp] lemma func_sigma {k} (f : (L i).Func k) (v : Fin k → M) :
    (sigma L M).func ⟨i, f⟩ v = func f v := rfl

@[simp] lemma rel_sigma {k} (r : (L i).Rel k) (v : Fin k → M) :
    (sigma L M).rel ⟨i, r⟩ v ↔ rel r v := iff_of_eq rfl

lemma lMap_sigma : (sigma L M).lMap (Language.Hom.sigma L i) = str i := rfl

@[simp] lemma val_lMap_sigma {n} (t : Semiterm (L i) μ n) (e : Fin n → M) (f : μ → M) :
    Semiterm.val (s := sigma L M) e f (t.lMap (Language.Hom.sigma L i)) =
        t.val (s := str i) e f := by
  rw [Semiterm.val_lMap, lMap_sigma]

@[simp] lemma eval_lMap_sigma {n} (φ : Semiformula (L i) μ n) (e : Fin n → M) (f : μ → M) :
    (Semiformula.lMap (Language.Hom.sigma L i) φ).Eval (s := sigma L M) e f
    ↔ φ.Eval (s := str i) e f := by
  rw [Semiformula.eval_lMap, lMap_sigma]

end sigma

end Tarski.Structure

section ULift

variable {L : Language.{u}} {M : Type v} [Tarski.Structure L M]

instance : Tarski.Structure L (ULift.{v'} M) where
  func _ f v := ⟨Tarski.Structure.func f (ULift.down ∘ v)⟩
  rel _ r v := Tarski.Structure.rel r (ULift.down ∘ v)

@[simp] lemma Tarski.Structure.func_uLift {k} (f : L.Func k) (v : Fin k → ULift.{v'} M) :
    Tarski.Structure.func f v = ⟨Tarski.Structure.func f (ULift.down ∘ v)⟩ := rfl

@[simp] lemma Tarski.Structure.rel_uLift {k} (r : L.Rel k) (v : Fin k → ULift.{v'} M) :
    Tarski.Structure.rel r v = Tarski.Structure.rel r (ULift.down ∘ v) := rfl

lemma Semiterm.val_uLift {e : Fin n → ULift.{v'} M} {f : ξ → ULift.{v'} M} {t : Semiterm L ξ n} :
    Semiterm.val e f t = ⟨Semiterm.val (ULift.down ∘ e) (ULift.down ∘ f) t⟩ := by
  induction t <;> simp [*, Function.comp_def]

lemma Semiformula.eval_uLift {e : Fin n → ULift.{v'} M} {f : ξ → ULift.{v'} M}
    {φ : Semiformula L ξ n} :
    φ.Eval e f ↔ φ.Eval (ULift.down ∘ e) (ULift.down ∘ f) := by
  induction φ using Semiformula.rec' <;>
    simp [*, Semiterm.val_uLift, Matrix.comp_vecCons', Function.comp_def]

variable (L M)

lemma uLift_elementaryEquiv [Nonempty M] : ULift.{v'} M ≡ₑ[L] M := ⟨by
  intro σ; simp [models_iff, Semiformula.eval_uLift, Matrix.empty_eq, Empty.eq_elim]⟩

end ULift

end FirstOrder

end FFL

end
