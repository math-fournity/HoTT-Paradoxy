module

public import Foundation.FirstOrder.Incompleteness.StandardProvability

@[expose] public section
/-!
# Consistency predicate
-/

open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding

namespace FFL.FirstOrder.Arithmetic.Bootstrapping

variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]

section WitnessComparisons

variable {L : Language} [L.Encodable] [L.LORDefinable]

section

variable (T : Theory L) [T.Δ₁] (V)

def _root_.FFL.FirstOrder.Theory.Consistent : Prop := ¬Provable T (⌜(⊥ : Sentence L)⌝ : V)

variable {V}

def _root_.FFL.FirstOrder.Theory.ConsistentWith (φ : V) : Prop := ¬Provable T (neg L φ)

lemma _root_.FFL.FirstOrder.Theory.ConsistentWith.quote_iff {σ : Sentence L} :
    T.ConsistentWith (⌜σ⌝ : V) ↔ ¬Provable T (⌜∼σ⌝ : V) := by
  simp [Theory.ConsistentWith, Sentence.quote_def, Semiformula.quote_def]

section

noncomputable def _root_.FFL.FirstOrder.Theory.consistent : 𝚷ᴬ₁.Sentence :=
  .mkPi (∼provabilityPred T ⊥)

@[simp] lemma consistent.defined :
    (T.consistent : ArithmeticSentence).Evalb (M := V) ![] ↔ T.Consistent V := by
  classical
  simp [Theory.consistent, Theory.Consistent]

noncomputable def _root_.FFL.FirstOrder.Theory.consistentWith : 𝚷ᴬ₁.Semisentence 1 := .mkPi
  “φ. ∀ nφ, !(negGraph L) nφ φ → ¬!(provable T) nφ”

instance consistentWith.defined :
    𝚷ᴬ₁-Predicate (T.ConsistentWith : V → Prop) via T.consistentWith :=
  .mk fun v ↦ by
  classical
  simp [Theory.ConsistentWith, Theory.consistentWith]

instance consistentWith.definable : 𝚷ᴬ₁-Predicate (T.ConsistentWith : V → Prop) :=
  (consistentWith.defined T).to_definable

noncomputable abbrev _root_.FFL.FirstOrder.Theory.consistentWithPred (σ : Sentence L) :
    ArithmeticSentence :=
  T.consistentWith.val/[⌜σ⌝]

noncomputable def _root_.FFL.FirstOrder.Theory.consistentWithPred' (σ : Sentence L) :
    𝚷ᴬ₁.Sentence :=
  .mkPi
  “!T.consistentWith !!(⌜σ⌝)”

@[simp] lemma consistentWithPred'_val (σ : Sentence L) :
    (T.consistentWithPred' σ).val = T.consistentWithPred' σ := by rfl

variable {T}

end

abbrev _root_.FFL.FirstOrder.Theory.Con : ArithmeticTheory := {T.consistent.val}

abbrev _root_.FFL.FirstOrder.Theory.Incon : ArithmeticTheory := {∼T.consistent.val}

noncomputable instance : T.Con.Δ₁ := Theory.Δ₁.singleton _

noncomputable instance : T.Incon.Δ₁ := Theory.Δ₁.singleton _

end

variable (T : ArithmeticTheory) [T.Δ₁] (V)

theorem consistent_eq : T.consistent = T.standardProvability.con := rfl

@[simp] lemma standard_consistent [𝗥₀ ⪯ T] : T.Consistent ℕ ↔ Entailment.Consistent T := by
  simp [Theory.Consistent, Entailment.consistent_iff_unprovable_bot]

end WitnessComparisons

end FFL.FirstOrder.Arithmetic.Bootstrapping

namespace FFL.FirstOrder.Arithmetic

open _root_.FFL.FirstOrder.Entailment

variable (T : ArithmeticTheory) [𝗜𝚺₁ ⪯ T] [T.Δ₁]

instance [ℕ↓[ℒₒᵣ] ⊧* T] : ℕ↓[ℒₒᵣ] ⊧* T ∪ T.Con := by
  have : 𝗥₀ ⪯ 𝗜𝚺₁ := inferInstance
  have : 𝗥₀ ⪯ T := Entailment.WeakerThan.trans this inferInstance
  have : Entailment.Consistent T := ArithmeticTheory.consistent_of_sound T (Eq ⊥) rfl
  simp [models_iff, *]

end FFL.FirstOrder.Arithmetic
