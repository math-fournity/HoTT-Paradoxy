module

public import Foundation.FirstOrder.Arithmetic.Bootstrapping.DerivabilityCondition.D1
public import Foundation.FirstOrder.Arithmetic.Bootstrapping.DerivabilityCondition.D2
public import Foundation.FirstOrder.Arithmetic.Bootstrapping.DerivabilityCondition.D3
public import Foundation.FirstOrder.Incompleteness.ProvabilityAbstraction.Basic
public import Foundation.FirstOrder.Arithmetic.Bootstrapping.FixedPoint
public import Foundation.FirstOrder.Incompleteness.Definability

@[expose] public section

open scoped FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Bounding
/-!
# Derivability conditions of standard provability predicate
-/

namespace FFL.FirstOrder.Arithmetic

open ISigma1 Bootstrapping ProvabilityAbstraction

noncomputable instance : Diagonalization 𝗜𝚺₁ where
  fixedpoint := fixedpoint
  diag θ := diagonal θ

section

variable {L : Language} [L.Encodable] [L.LORDefinable] {T : Theory L} [T.Δ₁]

local prefix:90 "□" => provabilityPred T

/-- The derivability condition D1. -/
theorem provable_D1 {σ} : T ⊢ σ → 𝗜𝚺₁ ⊢ □σ := fun h ↦
  complete 𝗜𝚺₁ _ fun (V : Type) _ _ ↦ by simpa [models_iff] using internalize_provability (V := V) h

/-- The derivability condition D2. -/
theorem provable_D2 {σ π} : 𝗜𝚺₁ ⊢ □(σ 🡒 π) 🡒 □σ 🡒 □π :=
  complete 𝗜𝚺₁ _ fun (V : Type) _ _ ↦ by simpa [models_iff] using modus_ponens_sentence T

variable (T)

noncomputable abbrev _root_.FFL.FirstOrder.Theory.standardProvability : Provability 𝗜𝚺₁ T where
  prov := provable T
  bew_def := provable_D1

variable {T}

instance : T.standardProvability.HBL2 := ⟨provable_D2⟩

lemma standardProvability_def (σ : Sentence L) :
    T.standardProvability σ = provabilityPred T σ := rfl

instance : T.standardProvability.SoundOn ℕ :=
  ⟨fun h ↦ by simpa [Arithmetic.standardProvability_def, models_iff] using h⟩

end

section arithmetic

variable {T U : ArithmeticTheory} [T.Δ₁]

local prefix:90 "□" => provabilityPred T

lemma provable_sigma_one_complete [𝗣𝗔⁻ ⪯ T] {σ : ArithmeticSentence}
    (hσ : ℬ[<, ℒₒᵣ].Hierarchy 𝚺 1 σ) :
    𝗜𝚺₁ ⊢ σ 🡒 □σ :=
  complete 𝗜𝚺₁ _ fun (V : Type) _ _ ↦ by
    simpa [models_iff] using Bootstrapping.Arithmetic.sigma_one_complete (T := T) (V := V) hσ

/-- The derivability condition D3. -/
theorem provable_D3 [𝗣𝗔⁻ ⪯ T] {σ : ArithmeticSentence} :
    𝗜𝚺₁ ⊢ □σ 🡒 □□σ := provable_sigma_one_complete (by simp)

open FFL.Entailment FFL.Entailment.FiniteContext

lemma provable_D2_context [𝗜𝚺₁ ⪯ U] {Γ σ π} (hσπ : Γ ⊢[U] □(σ 🡒 π)) (hσ : Γ ⊢[U] □σ) :
    Γ ⊢[U] □π := FiniteContext.of' (weakening inferInstance provable_D2) ⨀ hσπ ⨀ hσ

lemma provable_D3_context [𝗣𝗔⁻ ⪯ T] [𝗜𝚺₁ ⪯ U] {Γ σ} (hσπ : Γ ⊢[U] □σ) :
  Γ ⊢[U] □□σ := FiniteContext.of' (weakening inferInstance provable_D3) ⨀ hσπ

lemma provable_sound [U.SoundOnHierarchy 𝚺 1] {σ} : U ⊢ □σ → T ⊢ σ := fun h ↦ by
  have : ℕ↓[ℒₒᵣ] ⊧ provabilityPred T σ :=
    ArithmeticTheory.SoundOn.sound (F := ℬ[<, ℒₒᵣ].Hierarchy 𝚺 1) h (by simp)
  simpa [models_iff] using this

lemma provable_complete [U.SoundOnHierarchy 𝚺 1] [𝗜𝚺₁ ⪯ U] {σ} : T ⊢ σ ↔ U ⊢ □σ :=
  ⟨fun h ↦ weakening inferInstance (provable_D1 h), provable_sound⟩

instance [𝗣𝗔⁻ ⪯ T] : T.standardProvability.HBL3 := ⟨provable_D3⟩

instance [𝗣𝗔⁻ ⪯ T] : T.standardProvability.HBL where

instance [T.SoundOnHierarchy 𝚺 1] : T.standardProvability.Kreisel := ⟨fun h ↦ provable_sound h⟩

lemma models_standardProvability_iff {σ} : ℕ↓[ℒₒᵣ] ⊧ T.standardProvability σ ↔ T ⊢ σ :=
  ⟨T.standardProvability.sound_on,
    fun h ↦ models_of_provable inferInstance (T.standardProvability.D1 h)⟩

lemma soundOnHierarchy_iff_models_reflection :
    T.SoundOnHierarchy 𝚺 1 ↔
      ∀ σ, ℬ[<, ℒₒᵣ].Hierarchy 𝚺 1 σ → ℕ↓[ℒₒᵣ] ⊧ T.standardProvability σ 🡒 σ :=
  ⟨fun _ _ hσ ↦ Semantics.Imp.models_imply.mpr fun h ↦
      T.soundOnHierarchy 𝚺 1 (models_standardProvability_iff.mp h) hσ,
    fun h ↦ ⟨fun hσ hσ' ↦
      Semantics.Imp.models_imply.mp (h _ hσ') (models_standardProvability_iff.mpr hσ)⟩⟩

open FFL.Entailment in
/--
If `π` is equivalent to some 𝚺ᴬ₁ sentence `σ`,
then `π 🡒 □π` is provable in `T` (note: not `𝗜𝚺₁`, compare `provable_sigma_one_complete`)
-/
lemma provable_sigma_one_complete_of_E {σ π} [𝗜𝚺₁ ⪯ T]
  (hσ : ℬ[<, ℒₒᵣ].Hierarchy 𝚺 1 σ) (hσπ : 𝗜𝚺₁ ⊢ σ 🡘 π) : 𝗜𝚺₁ ⊢ π 🡒 □π := by
  apply C_replace ?_ ?_ <| provable_sigma_one_complete (T := T) <| hσ;
  · cl_prover [hσπ]
  · apply T.standardProvability.mono'
    cl_prover [hσπ];

variable [U.Δ₁] in
lemma provable_standardProvability_imp_of_Δ₁Class_subset
    (h : ∀ (V : Type) [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁] (p : V), p ∈ T.Δ₁Class → p ∈ U.Δ₁Class)
    (σ : ArithmeticSentence) :
    𝗜𝚺₁ ⊢ T.standardProvability σ 🡒 U.standardProvability σ :=
  complete 𝗜𝚺₁ _ fun (V : Type) _ _ ↦ by
    simpa [models_iff, standardProvability_def] using
      fun hp ↦ (hp.toDerivable.of_ss (h V)).toProvable

section

variable {Γ : Polarity} {m n : ℕ}

lemma InductionOnPrenexHierarchy.provable_standardProvability_imp_Peano (m : ℕ)
    (σ : ArithmeticSentence) :
    𝗜𝚺₁ ⊢ (𝗜𝗡𝗗 Γ m).standardProvability σ 🡒 𝗣𝗔.standardProvability σ :=
  provable_standardProvability_imp_of_Δ₁Class_subset (fun _ _ _ _ hp ↦ Peano.mem_Δ₁Class_iff.mpr <|
    (mem_Δ₁Class_iff.mp hp).imp_right <| InductionR.mono fun _ _ ↦ trivial) σ

lemma InductionOnHierarchy.provable_standardProvability_imp_of_le (h : m ≤ n)
    (σ : ArithmeticSentence) :
    𝗜𝚺₁ ⊢ (𝗜𝗡𝗗⁺ Γ m).standardProvability σ 🡒 (𝗜𝗡𝗗⁺ Γ n).standardProvability σ :=
  provable_standardProvability_imp_of_Δ₁Class_subset (fun _ _ _ _ hp ↦ mem_Δ₁Class_iff.mpr <|
    (mem_Δ₁Class_iff.mp hp).imp_right <| InductionR.mono fun _ ↦ IsHierarchy.mono h) σ

lemma InductionOnHierarchy.provable_standardProvability_imp_Peano (m : ℕ)
    (σ : ArithmeticSentence) :
    𝗜𝚺₁ ⊢ (𝗜𝗡𝗗⁺ Γ m).standardProvability σ 🡒 𝗣𝗔.standardProvability σ :=
  provable_standardProvability_imp_of_Δ₁Class_subset (fun _ _ _ _ hp ↦ Peano.mem_Δ₁Class_iff.mpr <|
    (mem_Δ₁Class_iff.mp hp).imp_right <| InductionR.mono fun _ _ ↦ trivial) σ

end

end arithmetic

open FFL.Entailment in
lemma exists_true_but_unprovable_sentence_of_incomplete {T : ArithmeticTheory} (h : Incomplete T) :
    ∃ δ : ArithmeticSentence, ℕ↓[ℒₒᵣ] ⊧ δ ∧ T ⊬ δ := by
  obtain ⟨δ, hδ⟩ := incomplete_def.mp h;
  by_cases ℕ↓[ℒₒᵣ] ⊧ δ
  · exact ⟨δ, by assumption, hδ.1⟩
  · exact ⟨∼δ, by simpa, hδ.2⟩

end FFL.FirstOrder.Arithmetic
