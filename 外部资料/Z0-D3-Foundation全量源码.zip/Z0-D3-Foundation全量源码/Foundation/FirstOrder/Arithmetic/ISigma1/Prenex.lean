module

public import Foundation.FirstOrder.Arithmetic.Induction.Equiv

/-!
# Prenex normal form theorem over $\mathsf{I\Sigma_1}$

Every `ℬ[<, ℒₒᵣ].Hierarchy 𝚺 1` formula is `𝗜𝚺₁`-provably equivalent to a formula of the form `∃¹ θ`
with `θ` bounded, and dually for `ℬ[<, ℒₒᵣ].Hierarchy 𝚷 1` and `∀¹ θ`.
-/

@[expose] public section

open FFL
open FFL.FirstOrder

namespace FFL.FirstOrder.Arithmetic.ISigma1

variable {n : ℕ} {φ : ArithmeticSemisentence n} {σ : ArithmeticSentence}

lemma hasPrenex (h : ℬ[<, ℒₒᵣ].Hierarchy 𝚺 1 φ) :
    ∃ φ' : ℬ[<, ℒₒᵣ].Prenex 𝚺 1 Empty n, 𝗜𝚺₁ ⊢ ∀¹* (φ 🡘 φ'.val) :=
  exists_prenex_of_hierarchy 𝗜𝚺₁ h

lemma exists_matrix_provable (h : ℬ[<, ℒₒᵣ].Hierarchy 𝚺 1 φ) :
    ∃ θ : ℬ[<, ℒₒᵣ].Semisentence (n + 1), 𝗜𝚺₁ ⊢ ∀¹* (φ 🡘 ∃¹ θ.val) := by
  obtain ⟨φ', hφ'⟩ := hasPrenex h;
  exact ⟨φ'.sigmaInv.matrix, Bounding.Prenex.provable_iff_sigmaInv hφ'⟩

lemma exists_matrix_provable_pi (h : ℬ[<, ℒₒᵣ].Hierarchy 𝚷 1 φ) :
    ∃ θ : ℬ[<, ℒₒᵣ].Semisentence (n + 1), 𝗜𝚺₁ ⊢ ∀¹* (φ 🡘 ∀¹ θ.val) := by
  obtain ⟨φ', hφ'⟩ := exists_prenex_of_hierarchy 𝗜𝚺₁ h
  exact ⟨φ'.piInv.matrix, Bounding.Prenex.provable_iff_piInv hφ'⟩

lemma exists_matrix_provable_of_sentence (h : ℬ[<, ℒₒᵣ].Hierarchy 𝚺 1 σ) :
    ∃ θ : ℬ[<, ℒₒᵣ].Semisentence 1, 𝗜𝚺₁ ⊢ σ 🡘 ∃¹ θ.val :=
  exists_matrix_provable h

end FFL.FirstOrder.Arithmetic.ISigma1
