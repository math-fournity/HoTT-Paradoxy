module

public import Foundation.FirstOrder.Arithmetic.LE

@[expose] public section
/-! # Preperations for arithmetic

- *NOTE*:
  To avoid the duplicate definitions of `Tarski.Structure ℒₒᵣ` for models,
  we basically use `ORingStructure`, and generated `standardStructure` instead of
  `Tarski.Structure ℒₒᵣ` itself.
-/

namespace FFL

class ORingStructure (α : Type*) extends Zero α, One α, Add α, Mul α, LT α

instance {α : Type*} [Zero α] [One α] [Add α] [Mul α] [LT α] : ORingStructure α where

namespace ORingStructure

variable {α : Type*} [ORingStructure α]

def numeral : ℕ → α
  |     0 => 0
  |     1 => 1
  | n + 2 => numeral (n + 1) + 1

@[simp] lemma zero_eq_zero : (numeral 0 : α) = 0 := rfl

@[simp] lemma one_eq_one : (numeral 1 : α) = 1 := rfl

end ORingStructure

@[simp] lemma Nat.numeral_eq : (n : ℕ) → ORingStructure.numeral n = n
  |     0 => rfl
  |     1 => rfl
  | n + 2 => by simp [ORingStructure.numeral, Nat.numeral_eq (n + 1)]

namespace FirstOrder

abbrev ArithmeticTheory := Theory ℒₒᵣ

abbrev ArithmeticSemiterm (ξ : Type*) (n : ℕ) := Semiterm ℒₒᵣ ξ n

abbrev ArithmeticTerm (ξ : Type*) := Term ℒₒᵣ ξ

abbrev ArithmeticSemiformula (ξ : Type*) (n : ℕ) := Semiformula ℒₒᵣ ξ n

abbrev ArithmeticFormula (ξ : Type*) := Formula ℒₒᵣ ξ

abbrev ArithmeticSemisentence (n : ℕ) := Semisentence ℒₒᵣ n

abbrev ArithmeticSentence := Sentence ℒₒᵣ

abbrev ArithmeticSemiproposition (n : ℕ) := Semiproposition ℒₒᵣ n

abbrev ArithmeticProposition := Proposition ℒₒᵣ

section ToString

variable {L : Language} [L.ORing]

variable {ξ : Type*} {n : ℕ} [ToString ξ]

def Semiterm.toStringORing : ArithmeticSemiterm ξ n → String
  |                        #x => "x_{" ++ toString (n - 1 - (x : ℕ)) ++ "}"
  |                        &x => "a_{" ++ toString x ++ "}"
  | func Language.Zero.zero _ => "0"
  |   func Language.One.one _ => "1"
  |   func Language.Add.add v =>
    "(" ++ toStringORing (v 0) ++ " + " ++ toStringORing (v 1) ++ ")"
  |   func Language.Mul.mul v =>
    "(" ++ toStringORing (v 0) ++ " \\cdot " ++ toStringORing (v 1) ++ ")"

instance : Repr (ArithmeticSemiterm ξ n) := ⟨fun t _ ↦ t.toStringORing⟩

instance : ToString (ArithmeticSemiterm ξ n) := ⟨Semiterm.toStringORing⟩

def Semiformula.toStringORing : ∀ {n}, ArithmeticSemiformula ξ n → String
  | _,                             ⊤ => "\\top"
  | _,                             ⊥ => "\\bot"
  | _,          rel Language.Eq.eq v => (v 0).toStringORing ++ " = " ++ (v 1).toStringORing
  | _,          rel Language.LT.lt v => (v 0).toStringORing ++ " < " ++ (v 1).toStringORing
  | _,         nrel Language.Eq.eq v => (v 0).toStringORing ++ " \\not = " ++ (v 1).toStringORing
  | _,         nrel Language.LT.lt v => (v 0).toStringORing ++ " \\not < " ++ (v 1).toStringORing
  | _,                         φ ⋏ ψ =>
    "[" ++ φ.toStringORing ++ "]" ++ " \\land " ++ "[" ++ ψ.toStringORing ++ "]"
  | _,                         φ ⋎ ψ =>
    "[" ++ φ.toStringORing ++ "]" ++ " \\lor "  ++ "[" ++ ψ.toStringORing ++ "]"
  | n, ∀¹ (rel Language.LT.lt v 🡒 φ) =>
    "(\\forall x_{" ++ toString n ++ "} < " ++ (v 1).toStringORing ++ ") " ++
      "[" ++ φ.toStringORing ++ "]"
  | n, ∃¹ (rel Language.LT.lt v ⋏ φ) =>
    "(\\exists x_{" ++ toString n ++ "} < " ++ (v 1).toStringORing ++ ") " ++
      "[" ++ φ.toStringORing ++ "]"
  | n,                          ∀¹ φ =>
    "(\\forall x_{" ++ toString n ++ "}) " ++ "[" ++ φ.toStringORing ++ "]"
  | n,                          ∃¹ φ =>
    "(\\exists x_{" ++ toString n ++ "}) " ++ "[" ++ φ.toStringORing ++ "]"

instance : Repr (ArithmeticSemiformula ξ n) := ⟨fun φ _ ↦ φ.toStringORing⟩

instance : ToString (ArithmeticSemiformula ξ n) := ⟨Semiformula.toStringORing⟩

end ToString

namespace Arithmetic

open Encodable Semiterm.Operator.GödelNumber

variable {α} [Encodable α]

instance : Semiterm.Operator.GödelNumber ℒₒᵣ α :=
  Semiterm.Operator.GödelNumber.ofEncodable

lemma gödelNumber_def (a : α) :
  gödelNumber a = Semiterm.Operator.encode ℒₒᵣ a := rfl

lemma gödelNumber'_def {ξ : Type*} {n : ℕ} (a : α) :
  (⌜a⌝ : ArithmeticSemiterm ξ n) = Semiterm.Operator.encode ℒₒᵣ a := rfl

lemma gödelNumber'_eq_coe_encode {ξ : Type*} {n : ℕ} (a : α) :
  (⌜a⌝ : ArithmeticSemiterm ξ n) = ↑(Encodable.encode a) := rfl

@[simp] lemma encode_encode_eq (a : α) :
    (gödelNumber (encode a) : Semiterm.Const ℒₒᵣ) = gödelNumber a := by
  simp [Semiterm.Operator.encode, gödelNumber_def]

@[simp] lemma rew_gödelNumber' {ξ₁ : Type*} {n₁ : ℕ} {ξ₂ : Type*} {n₂ : ℕ}
    (ω : Rew ℒₒᵣ ξ₁ n₁ ξ₂ n₂) (a : α) :
    ω ⌜a⌝ = ⌜a⌝ := by
  simp [gödelNumber'_def]

end Arithmetic

/-! ### Semantics of arithmetic  -/

class Tarski.Structure.ORing (L : Language) [L.ORing] (M : Type*) [ORingStructure M]
    [Tarski.Structure L M] extends
  Tarski.Structure.Zero L M, Tarski.Structure.One L M, Tarski.Structure.Add L M,
  Tarski.Structure.Mul L M, Tarski.Structure.Eq L M, Tarski.Structure.LT L M

attribute [instance] Tarski.Structure.ORing.mk

namespace Tarski.Structure

open Semiterm Semiformula

variable {L : Language} [Operator.Zero L] [Operator.One L] [Operator.Add L] {M : Type*}
  [ORingStructure M] [Tarski.Structure L M] [Tarski.Structure.Zero L M]
  [Tarski.Structure.One L M] [Tarski.Structure.Add L M]

@[simp] lemma numeral_eq_numeral :
    (z : ℕ) → (Semiterm.Operator.numeral L z).val ![] = (ORingStructure.numeral z : M)
  | 0     => by simp [ORingStructure.numeral, Semiterm.Operator.numeral_zero]
  | 1     => by simp [ORingStructure.numeral, Semiterm.Operator.numeral_one]
  | z + 2 => by simp [ORingStructure.numeral, Semiterm.Operator.numeral_add_two,
                  Semiterm.Operator.val_comp, Matrix.fun_eq_vec_two, numeral_eq_numeral (z + 1)]

end Tarski.Structure

namespace Semiformula

variable {L : Language} [L.LT] [L.Zero] [L.One] [L.Add] {ξ : Type*} {n : ℕ}

def ballLTSucc (t : Semiterm L ξ n) (φ : Semiformula L ξ (n + 1)) : Semiformula L ξ n :=
  φ.ballLT ‘!!t + 1’

def bexsLTSucc (t : Semiterm L ξ n) (φ : Semiformula L ξ (n + 1)) : Semiformula L ξ n :=
  φ.bexsLT ‘!!t + 1’

variable {M : Type*} {s : Tarski.Structure L M} [LT M] [One M] [Add M] [Tarski.Structure.LT L M]
  [Tarski.Structure.One L M] [Tarski.Structure.Add L M]

lemma eval_ballLTSucc {φ : Semiformula L ξ (n + 1)} {t : Semiterm L ξ n} {fv bv} :
    (φ.ballLTSucc t).Eval (M := M) fv bv ↔
      ∀ x < t.val (M := M) fv bv + 1, φ.Eval (M := M) (x :> fv) bv := by
  simp [ballLTSucc, Semiterm.Operator.numeral]

lemma eval_bexsLTSucc {φ : Semiformula L ξ (n + 1)} {t : Semiterm L ξ n} {fv bv} :
    (φ.bexsLTSucc t).Eval (M := M) fv bv ↔
      ∃ x < t.val (M := M) fv bv + 1, φ.Eval (M := M) (x :> fv) bv := by
  simp [bexsLTSucc, Semiterm.Operator.numeral]

end Semiformula

namespace BinderNotation

open Lean PrettyPrinter Delaborator SubExpr

/-- `∀ x <⁺ t, φ` states that `∀ x < t + 1, φ`. -/
syntax:max "∀ " ident " <⁺ " first_order_term ", " first_order_formula:0 : first_order_formula

/-- `∃ x <⁺ t, φ` states that `∃ x < t + 1, φ`. -/
syntax:max "∃ " ident " <⁺ " first_order_term ", " first_order_formula:0 : first_order_formula

macro_rules
  | `(⤫formula(lit)[ $binders* | $fbinders* | ∀ $x <⁺ $t, $φ]) => do
    if binders.elem x then Macro.throwErrorAt x "error: variable is duplicated." else
    let binders' := binders.insertIdx 0 x
    `(Semiformula.ballLTSucc ⤫term(lit)[ $binders* | $fbinders* | $t ]
      ⤫formula(lit)[ $binders'* | $fbinders* | $φ ])
  | `(⤫formula(lit)[ $binders* | $fbinders* | ∃ $x <⁺ $t, $φ]) => do
    if binders.elem x then Macro.throwErrorAt x "error: variable is duplicated." else
    let binders' := binders.insertIdx 0 x
    `(Semiformula.bexsLTSucc ⤫term(lit)[ $binders* | $fbinders* | $t ]
      ⤫formula(lit)[ $binders'* | $fbinders* | $φ ])

end BinderNotation

end FirstOrder

end FFL
