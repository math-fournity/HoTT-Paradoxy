module

public import Foundation.FirstOrder.LK.Completeness

@[expose] public section
namespace FFL

namespace FirstOrder

universe u w

variable {L : Language.{u}} [Semiformula.Operator.Eq L] [Semiformula.Operator.LT L]

open Semiformula

def LT.le : Operator L 2 := Semiformula.Operator.Eq.eq.or Semiformula.Operator.LT.lt

lemma le_eq {μ : Type*} {n : ℕ} (t₁ t₂ : Semiterm L μ n) :
    LT.le.operator ![t₁, t₂] = “!!t₁ = !!t₂ ∨ !!t₁ < !!t₂” := by
  simp [Operator.operator, Operator.or, LT.le, ←TransitiveRewriting.comp_app]

namespace Order
variable {T : Theory L} [𝗘𝗤 L ⪯ T]

omit [𝗘𝗤 L ⪯ T] in
theorem leIffEqOrLt : T ⊢ “∀ x y, x ≤ y ↔ x = y ∨ x < y” :=
  Theory.Proof.small_complete
    <| consequence_iff.mpr fun _ ↦ by simp [models_iff, Semiformula.Operator.LE.def_of_Eq_of_LT]

lemma complete (φ : Sentence L)
  (H : ∀ (M : Type (max u w))
      [Nonempty M] [LT M]
      [Tarski.Structure L M] [Tarski.Structure.Eq L M] [Tarski.Structure.LT L M]
      [M↓[L] ⊧* T],
      M↓[L] ⊧ φ) :
    T ⊢ φ := Theory.Proof.complete <| consequence_iff_eq.mpr fun M _ _ _ hT ↦
  letI : (Tarski.Structure.Model L M)↓[L] ⊧* T :=
    Tarski.Structure.ElementaryEquiv.modelsTheory.mp hT
  Tarski.Structure.ElementaryEquiv.models.mpr (H (Tarski.Structure.Model L M))

end Order

end FirstOrder

end FFL
