module

public import Foundation.FirstOrder.Arithmetic.Bootstrapping.Syntax.Formula.Coding
public import Foundation.FirstOrder.Syntax.Classical.PrimrecCoding
public import Foundation.Vorspiel.Computability

@[expose] public section

open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
namespace FFL.FirstOrder.Theory

variable {L : Language} [L.Encodable] [L.LORDefinable]

/-- TODO: define predicate `VariableFree` and make `mem_iff`
`∀ φ : Sentence, ℕ ⊧/![⌜φ⌝] ch.val ↔ φ ∈ T` -/
class Δ₁ (T : Theory L) where
  ch : 𝚫ᴬ₁.Semisentence 1
  mem_iff : ∀ φ : Proposition L, ℕ ⊧/![⌜φ⌝] ch.val ↔ ∃ σ ∈ T, φ = σ
  isDelta1 : ch.ProvablyProperOn 𝗜𝚺₁

abbrev Δ₁ch (T : Theory L) [T.Δ₁] : 𝚫ᴬ₁.Semisentence 1 := Δ₁.ch T

variable [L.Primcodable]

class RE (T : Theory L) : Prop where
  re : REPred (· ∈ T)

protected class Primrec (T : Theory L) : Prop where
  primrec : PrimrecPred (· ∈ T)

instance {T : Theory L} [T.Primrec] : T.RE :=
  ⟨Theory.Primrec.primrec.computablePred.to_re⟩

namespace RE

variable {T U : Theory L}

omit [L.LORDefinable] in
lemma add (hT : T.RE) (hU : U.RE) : (T ∪ U).RE :=
  ⟨(REPred.or hT.re hU.re).of_eq fun _ ↦ Iff.rfl⟩

variable [L.DecidableEq]

omit [L.LORDefinable] in
lemma ofFinite (hT : Set.Finite T) : T.RE := by
  constructor;
  simpa using show REPred (· ∈ hT.toFinset) by
    induction hT.toFinset using Finset.induction_on with
    | empty => exact (REPred.const False).of_eq fun _ ↦ by simp
    | @insert σ s _ ih =>
      exact ((PrimrecPred.computablePred
        (Primrec.eq.comp Primrec.id (Primrec.const σ))).to_re.or ih).of_eq fun _ ↦ by simp

end RE

end FFL.FirstOrder.Theory

namespace FFL.FirstOrder.Arithmetic.Bootstrapping

variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]

variable {L : Language} [L.Encodable] [L.LORDefinable]

def _root_.FFL.FirstOrder.Theory.Δ₁Class (T : Theory L) [T.Δ₁] : Set V :=
  { φ : V | V ⊧/![φ] T.Δ₁ch.val }

variable {T : Theory L} [T.Δ₁]

instance Δ₁Class.defined : 𝚫ᴬ₁-Predicate[V] (· ∈ T.Δ₁Class) via T.Δ₁ch := .mk <| by
  constructor
  · intro v
    have : V ⊧/![v 0] (Theory.Δ₁.ch T).sigma.val ↔ V ⊧/![v 0] (Theory.Δ₁.ch T).pi.val := by
      have := (consequence_iff (T := 𝗜𝚺₁)).mp
        (Theory.Proof.sound <| FirstOrder.Theory.Δ₁.isDelta1 (T := T)) V inferInstance
      simp [models_iff] at this ⊢
      simpa [Matrix.constant_eq_singleton] using this ![v 0]
    rwa [Matrix.fun_eq_vec_one v]
  · intro v; simp [←Matrix.fun_eq_vec_one, Theory.Δ₁Class]

instance Δ₁Class.definable : 𝚫ᴬ₁-Predicate[V] (· ∈ T.Δ₁Class) := Δ₁Class.defined.to_definable

@[simp] lemma Δ₁Class.proper : T.Δ₁ch.ProperOn V := (Theory.Δ₁.isDelta1 (T := T)).properOn V

@[simp] lemma Δ₁Class.mem_iff_s {φ : Proposition L} : (⌜φ⌝ : V) ∈ T.Δ₁Class ↔ ∃ σ ∈ T, φ = σ :=
  have : V ⊧/![⌜φ⌝] T.Δ₁ch.val ↔ ℕ ⊧/![⌜φ⌝] T.Δ₁ch.val := by
    simpa [Semiformula.coe_quote_eq_quote, Matrix.constant_eq_singleton]
      using FirstOrder.Arithmetic.models_iff_of_Delta1
        (V := V) (σ := T.Δ₁ch) (by simp) (by simp) (e := ![⌜φ⌝])
  Iff.trans this (Theory.Δ₁.mem_iff _)

@[simp] lemma Δ₁Class.mem_iff {φ : Sentence L} : (⌜φ⌝ : V) ∈ T.Δ₁Class ↔ φ ∈ T := by
  simp [Sentence.quote_def, Δ₁Class.mem_iff_s]

@[simp] lemma Δ₁Class.mem_iff' {φ : Sentence L} : V ⊧/![⌜φ⌝] T.Δ₁ch.val ↔ φ ∈ T := Δ₁Class.mem_iff

@[simp] lemma Δ₁Class.mem_iff'_s {φ : Proposition L} :
    V ⊧/![⌜φ⌝] T.Δ₁ch.val ↔ ∃ σ ∈ T, φ = σ := Δ₁Class.mem_iff_s

@[simp] lemma Δ₁Class.mem_iff'' {φ : Sentence L} :
    ((⌜φ⌝ : Bootstrapping.Formula V L).val : V) ∈ T.Δ₁Class ↔ φ ∈ T :=
  Δ₁Class.mem_iff

end FFL.FirstOrder.Arithmetic.Bootstrapping

namespace FFL.FirstOrder.Theory

variable {L : Language} [L.Encodable] [L.LORDefinable]

variable {T U : Theory L}

namespace Δ₁

abbrev add (dT : T.Δ₁) (dU : U.Δ₁) : (T ∪ U).Δ₁ where
  ch := T.Δ₁ch ⋎ U.Δ₁ch
  mem_iff {φ} := by
    simp only [Nat.succ_eq_add_one, Nat.reduceAdd, Bounding.HierarchySymbol.Semiformula.val_or,
      LogicalConnective.HomClass.map_or,
      FirstOrder.Arithmetic.Bootstrapping.Δ₁Class.mem_iff'_s, LogicalConnective.Prop.or_eq,
      Set.mem_union]
    grind
  isDelta1 :=
    Bounding.HierarchySymbol.Semiformula.ProvablyProperOn.arithmetic_ofProperOn.{0} _
      (fun V _ _ ↦
        Bounding.HierarchySymbol.Semiformula.ProperOn.or (by simp) (by simp))

instance [T.Δ₁] [U.Δ₁] : (T ∪ U).Δ₁ := add inferInstance inferInstance

@[simp] lemma _root_.FFL.FirstOrder.Theory.Δ₁Class.mem_union {V : Type*} [ORingStructure V]
    [T.Δ₁] [U.Δ₁] {p : V} : p ∈ (T ∪ U).Δ₁Class ↔ p ∈ T.Δ₁Class ∨ p ∈ U.Δ₁Class := by
  change V ⊧/![p] (T.Δ₁ch ⋎ U.Δ₁ch).val ↔ _
  simp [Theory.Δ₁Class]

abbrev ofEq (dT : T.Δ₁) (h : T = U) : U.Δ₁ where
  ch := dT.ch
  mem_iff := by rcases h; exact dT.mem_iff
  isDelta1 := by rcases h; exact dT.isDelta1

instance empty : Theory.Δ₁ (∅ : Theory L) where
  ch := ⊥
  mem_iff {ψ} := by simp
  isDelta1 :=
    Bounding.HierarchySymbol.Semiformula.ProvablyProperOn.arithmetic_ofProperOn.{0} _
      (fun V _ _ ↦ by simp)

abbrev singleton (φ : Sentence L) : Theory.Δ₁ {φ} where
  ch := .ofZero (.mkSigma “x. x = ↑(Encodable.encode φ)”) _
  mem_iff {ψ} := by simp [Semiformula.quote_eq_encode]
  isDelta1 :=
    Bounding.HierarchySymbol.Semiformula.ProvablyProperOn.arithmetic_ofProperOn.{0} _
      (fun V _ _ ↦ by intro; rfl)

@[simp] lemma singleton_toTDef_ch_val (φ : Sentence L) :
    letI := Δ₁.singleton φ
    ({φ} : Theory L).Δ₁ch.val = “x. x = ↑(Encodable.encode φ)” := by rfl

abbrev ofList (l : List (Sentence L)) : Δ₁ {φ | φ ∈ l} :=
  match l with
  |     [] => empty.ofEq (by ext; simp)
  | φ :: l => ((singleton φ).add (ofList l)).ofEq (by ext; simp)

noncomputable abbrev ofFinite (T : Theory L) (h : Set.Finite T) : T.Δ₁ :=
  (ofList h.toFinset.toList).ofEq (by ext; simp)

instance (φ : Sentence L) : Theory.Δ₁ {φ} := singleton φ

instance insert {φ : Sentence L} [d : T.Δ₁] : (insert φ T).Δ₁ :=
  (d.add (singleton φ)).ofEq (by ext; simp)

end Δ₁

end FFL.FirstOrder.Theory
