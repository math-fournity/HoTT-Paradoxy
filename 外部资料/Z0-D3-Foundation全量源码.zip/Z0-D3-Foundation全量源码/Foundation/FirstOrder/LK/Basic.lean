module

/- public import Foundation.Logic.Calculus -/
public import Foundation.Logic.Calculus
public import Foundation.Propositional.Entailment.Int
public import Foundation.FirstOrder.Syntax.Classical.Rew
public import Mathlib.Data.List.MinMax

/-! # One-sided sequent calculus for first-order classical logic -/

@[expose] public section
set_option autoImplicit true

namespace FFL

namespace FirstOrder

variable {L : Language}

abbrev LK.Sequent (L : Language) := Multiset (Proposition L)

namespace LK.Sequent

open Semiformula

def newVar (Γ : LK.Sequent L) : ℕ := (Γ.map Semiformula.fvSup).foldr max 0

lemma not_fvar?_newVar {φ : Proposition L} {Γ : LK.Sequent L} (h : φ ∈ Γ) :
    ¬FVar? φ Γ.newVar :=
  not_fvar?_of_lt_fvSup φ <| by
    simp only [newVar]
    induction Γ using Multiset.induction_on with
    | empty => simp at h
    | @cons ψ Γ ih =>
      simp only [Multiset.map_cons, Multiset.foldr_cons]
      rcases Multiset.mem_cons.mp h with (rfl | h)
      · exact Nat.le_max_left _ _
      · exact (ih h).trans (Nat.le_max_right _ _)

def IsClosed (Γ : LK.Sequent L) : Prop := ∃ φ ∈ Γ, ∼φ ∈ Γ

def embed (Γ : Multiset (Sentence L)) : LK.Sequent L := Γ.map Rewriting.emb

@[simp] lemma embed_nil : embed (0 : Multiset (Sentence L)) = 0 := rfl

@[simp] lemma embed_singleton {φ : Sentence L} :
    embed (⦃φ⦄ : Multiset (Sentence L)) = ⦃(φ : Proposition L)⦄ := rfl

@[simp] lemma embed_add (Γ Δ : Multiset (Sentence L)) :
    embed (Γ + Δ) = embed Γ + embed Δ := by simp [embed]

@[simp] lemma embed_shift (Γ : Multiset (Sentence L)) :
    (embed Γ)⁺ = embed Γ := by simp [embed, Rewriting.shifts]

end LK.Sequent

/-! ## Derivation for $\mathbf{LK}$ -/

/-- Derivation for $\mathbf{LK}$ -/
inductive LK.Derivation : LK.Sequent L → Type _
| identity (r : L.Rel k) (v) : LK.Derivation ⦃.rel r v, .nrel r v⦄
| cut : LK.Derivation (Γ + ⦃φ⦄) → LK.Derivation (Δ + ⦃∼φ⦄) → LK.Derivation (Γ + Δ)
| contraction : LK.Derivation (Γ + ⦃φ, φ⦄) → LK.Derivation (Γ + ⦃φ⦄)
| weakening : LK.Derivation Γ → LK.Derivation (Γ + ⦃φ⦄)
| verum : LK.Derivation ⦃⊤⦄
| or : LK.Derivation (Γ + ⦃φ, ψ⦄) → LK.Derivation (Γ + ⦃φ ⋎ ψ⦄)
| and : LK.Derivation (Γ + ⦃φ⦄) → LK.Derivation (Γ + ⦃ψ⦄) → LK.Derivation (Γ + ⦃φ ⋏ ψ⦄)
| all : LK.Derivation (Γ⁺ + ⦃φ.free⦄) → LK.Derivation (Γ + ⦃∀¹ φ⦄)
| exs : LK.Derivation (Γ + ⦃φ/[t]⦄) → LK.Derivation (Γ + ⦃∃¹ φ⦄)

prefix:45 "⊢ᴸᴷ¹ " => LK.Derivation

namespace LK.Derivation

open Rewriting LawfulSyntacticRewriting

variable {Γ Δ : LK.Sequent L}

def height {Δ : LK.Sequent L} : ⊢ᴸᴷ¹ Δ → ℕ
  |  identity _ _ => 0
  |     cut dp dn => max dp.height dn.height + 1
  | contraction d => d.height + 1
  |   weakening d => d.height + 1
  |         verum => 0
  |          or d => d.height + 1
  |     and dp dq => max (height dp) (height dq) + 1
  |         all d => d.height + 1
  |         exs d => d.height + 1

section height

@[simp] lemma height_id {k} {r : L.Rel k} {v} :
  height (identity r v) = 0 := rfl

@[simp] lemma height_cut {φ} (dp : ⊢ᴸᴷ¹ Γ + ⦃φ⦄) (dn : ⊢ᴸᴷ¹ Δ + ⦃∼φ⦄) :
  height (cut dp dn) = (max (height dp) (height dn)).succ := rfl

@[simp] lemma height_contraction (d : ⊢ᴸᴷ¹ Γ + ⦃φ, φ⦄) :
    height (contraction d) = d.height.succ := rfl

@[simp] lemma height_weakening (d : ⊢ᴸᴷ¹ Γ) :
    height (weakening (φ := φ) d) = d.height.succ := rfl

@[simp] lemma height_verum : height (verum : ⊢ᴸᴷ¹ (⦃⊤⦄ : LK.Sequent L)) = 0 := rfl

@[simp] lemma height_and {φ ψ} (dp : ⊢ᴸᴷ¹ Γ + ⦃φ⦄) (dq : ⊢ᴸᴷ¹ Γ + ⦃ψ⦄) :
    height (and dp dq) = (max (height dp) (height dq)).succ := rfl

@[simp] lemma height_or {φ ψ} (d : ⊢ᴸᴷ¹ Γ + ⦃φ, ψ⦄) :
    height (or d) = d.height.succ := rfl

@[simp] lemma height_all {φ : Semiproposition L 1} (d : ⊢ᴸᴷ¹ Γ⁺ + ⦃φ.free⦄) :
    height (all d) = d.height.succ := rfl

@[simp] lemma height_exs {t} {φ} (d : ⊢ᴸᴷ¹ Γ + ⦃φ/[t]⦄) :
    height (exs d) = d.height.succ := rfl

end height

abbrev cast (d : ⊢ᴸᴷ¹ Δ) (e : Δ = Γ := by abel) : ⊢ᴸᴷ¹ Γ := e ▸ d

@[simp] lemma height_cast (d : ⊢ᴸᴷ¹ Δ) (e : Δ = Γ) :
    height (LK.Derivation.cast d e) = height d := by rcases e with rfl; simp [LK.Derivation.cast]

instance : Structural (LK.Derivation (L := L)) where
  weakening d := d.weakening
  contraction d := d.contraction

/-- Enumerates the end sequent by recursion on the local inference rules.
This is a routine syntactic construction. -/
def traversal [L.DecidableEq] {Γ : LK.Sequent L} : ⊢ᴸᴷ¹ Γ → Γ.Traversal
  | identity r v =>
      (Multiset.Traversal.atom (Semiformula.rel r v)).succ (Semiformula.nrel r v)
  | cut d dn => d.traversal.remove.add dn.traversal.remove
  | contraction (φ := φ) d => (d.traversal.cast (by abel)).remove (a := φ)
  | weakening (φ := φ) d => d.traversal.succ φ
  | verum => .atom ⊤
  | or (φ := φ) (ψ := ψ) d =>
      ((d.traversal.cast (by abel)).remove (a := ψ)).remove (a := φ) |>.succ (φ ⋎ ψ)
  | and (φ := φ) (ψ := ψ) d _ => d.traversal.remove.succ (φ ⋏ ψ)
  | all (Γ := Γ) (φ := φ) d =>
      ((d.traversal.remove.map (Rew.rewriteMap Nat.pred ▹ ·)).cast (by
        simp [Rewriting.shifts, Multiset.map_map, Rewriting.rewriteMap_pred_shift])).succ (∀¹ φ)
  | exs (φ := φ) d => d.traversal.remove.succ (∃¹ φ)

/-- Applies structural rules along supplied traversals (a routine derived rule). -/
def contra [L.DecidableEq] (d : ⊢ᴸᴷ¹ Δ) (t : Γ.Traversal)
    (h : Δ ⊆ Γ := by simp) : ⊢ᴸᴷ¹ Γ :=
  Structural.ofSubset (F := Proposition L) (𝔇 := LK.Derivation (L := L))
    (Γ := Δ) (Δ := Γ) (traversal (L := L) d) t d h

def tensor {φ ψ} (tΓ : Γ.Traversal) (tΔ : Δ.Traversal)
    (dφ : ⊢ᴸᴷ¹ Γ + ⦃φ⦄) (dψ : ⊢ᴸᴷ¹ Δ + ⦃ψ⦄) :
    ⊢ᴸᴷ¹ Γ + Δ + ⦃φ ⋏ ψ⦄ :=
  and
    (Structural.weakenMany tΔ dφ |>.cast)
    (Structural.weakenMany tΓ dψ |>.cast)

def eta : (φ : Proposition L) → ⊢ᴸᴷ¹ ⦃φ, ∼φ⦄
  | .rel R v => identity R v
  | .nrel R v => (identity R v).cast (by simp [add_comm])
  | ⊤ => verum.weakening
  | ⊥ => (verum.weakening (φ := ⊥)).cast (by simp [add_comm])
  | φ ⋏ ψ =>
    (or (Γ := ⦃φ ⋏ ψ⦄) (φ := ∼φ) (ψ := ∼ψ)
      (tensor (Γ := ⦃∼φ⦄) (Δ := ⦃∼ψ⦄) (φ := φ) (ψ := ψ)
        (Multiset.Traversal.atom _) (Multiset.Traversal.atom _)
        (eta φ).cast (eta ψ).cast).cast).cast (by simp [add_comm])
  | φ ⋎ ψ =>
    (or (Γ := ⦃∼φ ⋏ ∼ψ⦄) (φ := φ) (ψ := ψ)
      (tensor (Γ := ⦃φ⦄) (Δ := ⦃ψ⦄) (φ := ∼φ) (ψ := ∼ψ)
        (Multiset.Traversal.atom _) (Multiset.Traversal.atom _) (eta φ) (eta ψ)).cast).cast
      (by simp [add_comm])
  | ∀¹ φ =>
    (all (Γ := ⦃∃¹ ∼φ⦄) (φ := φ)
      ((exs (Γ := ⦃φ.free⦄) (φ := ∼φ.shift) (t := &0)
        ((eta φ.free).cast (by simp))).cast
      (by simp [add_comm]))).cast (by simp [add_comm])
  | ∃¹ φ =>
    (all (Γ := ⦃∃¹ φ⦄) (φ := ∼φ) (cast
      (exs (Γ := ⦃(∼φ).free⦄) (φ := φ.shift) (t := &0)
        ((eta φ.free).cast (by simp [add_comm])))
      (by simp [add_comm]))).cast (by simp)
  termination_by φ => φ.complexity

instance : OneSidedLK (LK.Derivation (L := L)) where
  verum := verum
  and d₁ d₂ := d₁.and d₂
  or d := d.or
  weakening d := d.weakening
  contraction d := d.contraction
  identity φ := eta φ

instance : OneSidedLK.Cut (LK.Derivation (L := L)) where
  cut dp dn := cut dp dn

lemma of_isClosed {Γ : LK.Sequent L} (h : Γ.IsClosed) : Nonempty (⊢ᴸᴷ¹ Γ) := by
  classical
  rcases h with ⟨φ, hp, hn⟩;
  exact ⟨contra (L := L) (eta φ) (default : Γ.Traversal) (by
    intro ψ hψ;
    simp only [Multiset.mem_add, Multiset.mem_atom_iff] at hψ;
    rcases hψ with rfl | rfl <;> assumption)⟩;

def rewrite {Γ} (f : ℕ → SyntacticTerm L) :
    ⊢ᴸᴷ¹ Γ → ⊢ᴸᴷ¹ Γ.map (Rew.rewrite f ▹ ·)
  | identity R v => identity R (Rew.rewrite f ∘ v)
  | cut (φ := φ) (Γ := Γ) (Δ := Δ) d₁ d₂ =>
    (cut (Γ := Γ.map (Rew.rewrite f ▹ ·))
      (Δ := Δ.map (Rew.rewrite f ▹ ·)) (φ := Rew.rewrite f ▹ φ)
      ((d₁.rewrite f).cast (by simp)) ((d₂.rewrite f).cast (by simp))).cast (by simp)
  | contraction (Γ := Γ) (φ := φ) d =>
      (contraction (Γ := Γ.map (Rew.rewrite f ▹ ·)) (φ := Rew.rewrite f ▹ φ)
        ((d.rewrite f).cast (by simp))).cast (by simp)
  | weakening (Γ := Γ) (φ := φ) d =>
      (weakening (φ := Rew.rewrite f ▹ φ) (d.rewrite f)).cast (by simp)
  | verum => verum
  | or (Γ := Γ) (φ := φ) (ψ := ψ) d =>
    (or (Γ := Γ.map (Rew.rewrite f ▹ ·))
      (φ := Rew.rewrite f ▹ φ) (ψ := Rew.rewrite f ▹ ψ)
      ((d.rewrite f).cast (by simp))).cast (by simp)
  | and (Γ := Γ) (φ := φ) (ψ := ψ) d₁ d₂ =>
    (and (Γ := Γ.map (Rew.rewrite f ▹ ·))
      (φ := Rew.rewrite f ▹ φ) (ψ := Rew.rewrite f ▹ ψ)
      ((d₁.rewrite f).cast (by simp)) ((d₂.rewrite f).cast (by simp))).cast (by simp)
  | all (φ := φ) (Γ := Γ) d =>
    let g : ℕ → SyntacticTerm L := &0 :>ₙ fun x ↦ Rew.shift (f x)
    have : ⊢ᴸᴷ¹ (Γ⁺ + ⦃φ.free⦄).map (Rew.rewrite g ▹ ·) := d.rewrite g
    (all (Γ := Γ.map (Rew.rewrite f ▹ ·))
      (φ := Rew.rewrite (Rew.bShift ∘ f) ▹ φ) (LK.Derivation.cast this (by
        simp [g, free_rewrite_eq, Rewriting.shifts, shift_rewrite_eq, Function.comp_def]))).cast
      (by simp [Rew.q_rewrite])
  | exs (φ := φ) (Γ := Γ) (t := t) d =>
    have : ⊢ᴸᴷ¹ (Γ + ⦃φ/[t]⦄).map (Rew.rewrite f ▹ ·) := d.rewrite f
    (exs (Γ := Γ.map (Rew.rewrite f ▹ ·))
      (φ := Rew.rewrite (Rew.bShift ∘ f) ▹ φ) (t := Rew.rewrite f t)
      (LK.Derivation.cast this (by simp [rewrite_subst_eq]))).cast (by simp [Rew.q_rewrite])

protected def map {Δ : LK.Sequent L} (d : ⊢ᴸᴷ¹ Δ) (f : ℕ → ℕ) :
    ⊢ᴸᴷ¹ Δ.map (Rew.rewriteMap f ▹ ·) := d.rewrite (fun x ↦ &(f x))

protected def shift {Δ : LK.Sequent L} (d : ⊢ᴸᴷ¹ Δ) : ⊢ᴸᴷ¹ Δ⁺ :=
  LK.Derivation.cast (LK.Derivation.map d Nat.succ) (by rfl)

section Hom

variable {L₁ : Language} {L₂ : Language} {Δ₁ : LK.Sequent L₁}

lemma shifts_image (Φ : L₁ →ᵥ L₂) {Δ : Multiset (Proposition L₁)} :
     (Δ.map <| Semiformula.lMap Φ)⁺ = (Δ⁺.map <| Semiformula.lMap Φ) := by
  simp [Rewriting.shifts, Semiformula.lMap_shift]

def lMap (Φ : L₁ →ᵥ L₂) {Γ} : ⊢ᴸᴷ¹ Γ → ⊢ᴸᴷ¹ Γ.map (.lMap Φ)
  | identity r v =>
    .cast (identity (Φ.rel r) (fun i ↦ .lMap Φ (v i)))
    (by simp [Function.comp_def])
  | cut (Γ := Γ) (Δ := Δ) (φ := φ) d dn =>
    (cut (Γ := Γ.map (.lMap Φ)) (Δ := Δ.map (.lMap Φ))
      (φ := .lMap Φ φ) (LK.Derivation.cast (lMap Φ d) (by simp))
      (LK.Derivation.cast (lMap Φ dn) (by simp))).cast (by simp)
  | contraction (Γ := Γ) (φ := φ) d =>
      (contraction (Γ := Γ.map (.lMap Φ)) (φ := .lMap Φ φ)
        ((lMap Φ d).cast (by simp))).cast (by simp)
  | weakening (φ := φ) d =>
      (weakening (φ := .lMap Φ φ) (lMap Φ d)).cast (by simp)
  | verum => by simpa using verum
  | or (Γ := Γ) (φ := φ) (ψ := ψ) d =>
    (or (Γ := Γ.map (.lMap Φ)) (φ := .lMap Φ φ) (ψ := .lMap Φ ψ)
      (LK.Derivation.cast (lMap Φ d) (by simp))).cast (by simp)
  | and (Γ := Γ) (φ := φ) (ψ := ψ) dp dq =>
    (and (Γ := Γ.map (.lMap Φ)) (φ := .lMap Φ φ) (ψ := .lMap Φ ψ)
      (LK.Derivation.cast (lMap Φ dp) (by simp))
      (LK.Derivation.cast (lMap Φ dq) (by simp))).cast (by simp)
  | all (Γ := Γ) (φ := φ) d =>
    (all (Γ := Γ.map (.lMap Φ)) (φ := .lMap Φ φ)
      (LK.Derivation.cast (lMap Φ d)
        (by simp [←Semiformula.lMap_free, shifts_image]))).cast (by simp)
  | exs (Γ := Γ) (φ := φ) (t := t) d =>
    (exs (Γ := Γ.map (.lMap Φ)) (φ := .lMap Φ φ)
      (t := Semiterm.lMap Φ t)
      (.cast (lMap Φ d) (by simp [Semiformula.lMap_subst]))).cast (by simp)

end Hom

private lemma map_subst_eq_free (φ : Semiproposition L 1) (h : ¬φ.FVar? m) :
    (@Rew.rewriteMap L ℕ ℕ 0 (fun x ↦ if x = m then 0 else x + 1)) ▹
      (φ/[&m] : Proposition L) = Rewriting.free φ := by
  simp only [← TransitiveRewriting.comp_app]
  exact Semiformula.rew_eq_of_funEqOn (by simp [Rew.comp_app])
    (fun x hx => by simp [Rew.comp_app, ne_of_mem_of_not_mem hx h])

private lemma map_rewriteMap_eq_shifts (Δ : LK.Sequent L) (h : ∀ φ ∈ Δ, ¬φ.FVar? m) :
    Δ.map (fun φ ↦ @Rew.rewriteMap L ℕ ℕ 0
      (fun x ↦ if x = m then 0 else x + 1) ▹ φ) = Δ⁺ := by
  apply Multiset.map_congr rfl
  intro φ hp
  exact Semiformula.rew_eq_of_funEqOn₀
    (by intro x hx; simp [ne_of_mem_of_not_mem hx (h φ hp)])

def generalizeByNewVar {φ : Semiproposition L 1} (hp : ¬φ.FVar? m)
    (hΔ : ∀ ψ ∈ Δ, ¬ψ.FVar? m) (d : ⊢ᴸᴷ¹ Δ + ⦃φ/[&m]⦄) :
    ⊢ᴸᴷ¹ Δ + ⦃∀¹ φ⦄ := by
  have : ⊢ᴸᴷ¹ Δ⁺ + ⦃φ.free⦄ :=
    LK.Derivation.cast (LK.Derivation.map d (fun x ↦ if x = m then 0 else x + 1))
    (by simp [map_subst_eq_free φ hp, map_rewriteMap_eq_shifts Δ hΔ])
  exact all this

end LK.Derivation

/-! ## Classical proof system -/

inductive LK (L : Language)
  | symbol

notation "𝐋𝐊¹" => LK.symbol

notation "𝐋𝐊¹[" L "]" => LK.symbol (L := L)

abbrev LK.Proof (φ : Proposition L) := ⊢ᴸᴷ¹ ⦃φ⦄

instance : Entailment (LK L) (Proposition L) where
  Entails _ φ := Nonempty (LK.Proof φ)

namespace LK.Proof

lemma provable_def (φ : Proposition L) :
    𝐋𝐊¹ ⊢ φ ↔ Nonempty (⊢ᴸᴷ¹ ⦃φ⦄) := by rfl

lemma unprovable_def (φ : Proposition L) :
    𝐋𝐊¹ ⊬ φ ↔ IsEmpty (⊢ᴸᴷ¹ ⦃φ⦄) := by
  unfold Entailment.Unprovable; simp [provable_def]

instance : OneSidedLK.PrincipalEntailment (LK.Derivation (L := L)) (𝐋𝐊¹ : LK L) where
  iff := Iff.rfl

instance classical : Entailment.Cl (𝐋𝐊¹ : LK L) := inferInstance

lemma all (φ : Semiproposition L 1) :
    𝐋𝐊¹ ⊢ φ.free → 𝐋𝐊¹ ⊢ ∀¹ φ := fun ⟨d⟩ ↦
  ⟨LK.Derivation.all (Γ := 0) (φ := φ) (d.cast (by simp [Rewriting.shifts]))⟩

lemma allClosure_fixitr {φ : Proposition L} (dp : 𝐋𝐊¹ ⊢ φ) :
    (m : ℕ) → 𝐋𝐊¹ ⊢ ∀¹* Rew.fixitr 0 m ▹ φ
  |     0 => by simpa
  | m + 1 => by
    simp only [LawfulSyntacticRewriting.allClosure_fixitr]
    apply all; simpa using allClosure_fixitr dp m

lemma univCl' {φ : Proposition L} (b : 𝐋𝐊¹ ⊢ φ) : 𝐋𝐊¹ ⊢ φ.univCl' :=
  allClosure_fixitr b φ.fvSup

lemma lMap (Φ : L₁ →ᵥ L₂) {φ : Proposition L₁} :
    𝐋𝐊¹ ⊢ φ → 𝐋𝐊¹ ⊢ φ.lMap Φ := by
  rintro ⟨d⟩
  have : ⊢ᴸᴷ¹ ⦃φ⦄ := d
  have : ⊢ᴸᴷ¹ ⦃.lMap Φ φ⦄ := this.lMap Φ
  exact ⟨this⟩

end LK.Proof

structure Theory.Proof (T : Theory L) (σ : Sentence L) where
  axioms : Multiset (Sentence L)
  axioms_mem : ∀ ψ ∈ axioms, ψ ∈ T
  derivation : OneSidedLK.Pullback LK.Derivation Rewriting.emb (⦃σ⦄ + ∼axioms)

namespace Theory.Proof

instance : Entailment (Theory L) (Sentence L) where
  Entails T σ := Nonempty (Theory.Proof T σ)

variable {T : Theory L}

attribute [simp] Theory.Proof.axioms_mem

/-- A singleton derivation gives a theory proof without using any axioms. -/
def ofDerivation {T : Theory L} {φ : Sentence L}
    (d : OneSidedLK.Pullback LK.Derivation Rewriting.emb ⦃φ⦄) : T.Proof φ :=
  ⟨0, by simp, OneSidedLK.cast d⟩

instance : Entailment.Compact (Theory L) where
  finite_provable := fun ⟨b⟩ ↦
    ⟨{φ | φ ∈ b.axioms}, by simpa [AdjunctiveSet.subset_iff] using b.axioms_mem,
      by simp [AdjunctiveSet.Finite, AdjunctiveSet.set], ⟨b.axioms, by simp, b.derivation⟩⟩

instance (T : Theory L) : Entailment.ModusPonens T where
  mdp {φ ψ} := fun ⟨bi⟩ ⟨bp⟩ ↦ by
    refine ⟨bi.axioms + bp.axioms, ?_, ?_⟩
    · exact Multiset.forall_mem_add.mpr ⟨bi.axioms_mem, bp.axioms_mem⟩
    · exact OneSidedLK.cast (OneSidedLK.modusPonens
        (Γ := ∼bi.axioms) (Δ := ∼bp.axioms) (φ := φ) (ψ := ψ)
        (OneSidedLK.cast bi.derivation) (OneSidedLK.cast bp.derivation)) (by simp; abel)

instance : Entailment.Cl T := OneSidedLK.AxiomDerivation.cl T fun d ↦ ⟨ofDerivation d⟩

instance : Entailment.Axiomatized (Theory L) where
  prfAxm {𝓢 φ} h :=
    ⟨⦃φ⦄, by simpa using h, by
      change ⊢ᴸᴷ¹ (⦃φ⦄ + ∼(⦃φ⦄ : Multiset (Sentence L))).map Rewriting.emb
      simpa [Multiset.tilde_def] using LK.Derivation.eta (Rewriting.emb φ)⟩
  weakening h := fun ⟨b⟩ ↦
    ⟨b.axioms, fun ψ hψ ↦ h (b.axioms_mem ψ hψ), b.derivation⟩

/-- Replaces each used axiom by its proof in another theory.
This is a routine consequence of implication introduction and modus ponens. -/
lemma cut {U : Theory L} (h : T ⊢* U) : U ⊢ φ → T ⊢ φ := fun ⟨b⟩ ↦
  let rec go (l : List (Sentence L)) (hl : ∀ ψ ∈ l, ψ ∈ U) {φ : Sentence L}
      (d : OneSidedLK.Pullback LK.Derivation Rewriting.emb (⦃φ⦄ + ∼(l : Multiset _))) :
      T ⊢ φ :=
    match l with
    | [] => ⟨ofDerivation (OneSidedLK.cast d (by simp))⟩
    | ψ :: l =>
      Entailment.mdp
        (go l (by simp_all) (φ := ψ 🡒 φ)
          (OneSidedLK.cast
            (OneSidedLK.or (Γ := ∼(l : Multiset _)) (φ := ∼ψ) (ψ := φ)
              (OneSidedLK.cast d (by
                change ⦃φ⦄ + ∼(ψ ::ₘ (l : Multiset _)) = _
                simp [Multiset.tilde_def, ← Multiset.add_atom_eq_cons, add_comm, add_left_comm])))
            (by simp [Semiformula.imp_eq]; abel)))
        (h (hl ψ (by simp)))
  go b.axioms.toList (by simpa using b.axioms_mem)
    (OneSidedLK.cast b.derivation (by simp))

instance : Entailment.StrongCut (Theory L) (Theory L) := ⟨cut⟩

instance : Entailment.DeductiveExplosion (Theory L) where
  dexp := fun ⟨b⟩ φ ↦ by
    refine ⟨b.axioms, b.axioms_mem, ?_⟩
    have db : ⊢ᴸᴷ¹ (∼LK.Sequent.embed b.axioms) + ⦃Rewriting.emb (⊥ : Sentence L)⦄ :=
      LK.Derivation.cast b.derivation
        (by simp [LK.Sequent.embed, add_comm, Multiset.map_tilde_comm])
    exact ((OneSidedLK.removeBot db).weakening (φ := Rewriting.emb φ)).cast (by
      simp [LK.Sequent.embed, add_comm, Multiset.map_tilde_comm])

lemma weakerThan_of_le {T U : Theory L} (h : T ⊆ U) : T ⪯ U :=
  Entailment.Axiomatized.weakerThanOfSubset h

instance (T U : Theory L) : T ⪯ T ∪ U := weakerThan_of_le (by simp)

instance (T U : Theory L) : U ⪯ T ∪ U := weakerThan_of_le (by simp)

lemma provable_iff :
    T ⊢ φ ↔ ∃ Γ : Multiset (Sentence L), (∀ ψ ∈ Γ, ψ ∈ T) ∧
      Nonempty (⊢ᴸᴷ¹ ⦃(φ : Proposition L)⦄ + ∼LK.Sequent.embed Γ) := by
  constructor
  · rintro ⟨b⟩
    exact ⟨b.axioms, b.axioms_mem,
      ⟨by simpa [OneSidedLK.Pullback, LK.Sequent.embed, Multiset.map_tilde_comm] using
        b.derivation⟩⟩
  · rintro ⟨Γ, hΓ, ⟨d⟩⟩
    exact ⟨Γ, hΓ, by simpa [OneSidedLK.Pullback, LK.Sequent.embed, Multiset.map_tilde_comm] using d⟩

lemma inconsistent_iff :
    Entailment.Inconsistent T ↔ ∃ Γ : Multiset (Sentence L), (∀ ψ ∈ Γ, ψ ∈ T) ∧
      Nonempty (⊢ᴸᴷ¹ ∼LK.Sequent.embed Γ) := by
  rw [Entailment.inconsistent_iff_provable_bot, provable_iff]
  constructor
  · rintro ⟨Γ, hΓ, ⟨d⟩⟩
    have db : ⊢ᴸᴷ¹ (∼LK.Sequent.embed Γ) + ⦃Rewriting.emb (⊥ : Sentence L)⦄ :=
      d.cast (by rw [add_comm])
    exact ⟨Γ, hΓ, ⟨OneSidedLK.removeBot db⟩⟩
  · rintro ⟨Γ, hΓ, ⟨d⟩⟩
    exact ⟨Γ, hΓ, ⟨(d.weakening (φ := Rewriting.emb (⊥ : Sentence L))).cast
      (by simp [add_comm])⟩⟩

open Entailment LK.Derivation

@[simp] lemma empty_provable_iff_eprovable :
    (∅ : Theory L) ⊢ φ ↔ 𝐋𝐊¹ ⊢ (φ : Proposition L) := by
  constructor
  · rintro ⟨b⟩
    have hzero : b.axioms = 0 := Multiset.eq_zero_of_forall_notMem fun ψ hψ ↦ by
      simpa using b.axioms_mem ψ hψ
    have d := b.derivation
    rw [hzero] at d
    change ⊢ᴸᴷ¹ ⦃Rewriting.emb φ⦄ at d
    exact ⟨d⟩
  · rintro ⟨d⟩
    change ⊢ᴸᴷ¹ ⦃Rewriting.emb φ⦄ at d
    exact ⟨ofDerivation d⟩

open Entailment LK.Derivation

lemma of_LK_provable {T : Theory L} {φ : Sentence L} :
    𝐋𝐊¹ ⊢ (φ : Proposition L) → T ⊢ φ := by
  rintro ⟨d⟩
  change ⊢ᴸᴷ¹ ⦃Rewriting.emb φ⦄ at d
  exact ⟨ofDerivation d⟩

lemma specialize {T : Theory L} (φ : Semisentence L 1) (t : ClosedTerm L) :
    T ⊢ ∀¹ φ 🡒 Semiformula.subst φ ![t] := by
  apply of_LK_provable
  refine ⟨?_⟩
  let φt : Sentence L := Semiformula.subst φ ![t]
  have d : ⊢ᴸᴷ¹ ⦃(φt : Proposition L)⦄ +
      ⦃(∼(φ : Semiproposition L 1))/[Rew.emb t]⦄ := by
    simpa [φt, Semiformula.coe_subst_eq_subst_coe₁] using
      LK.Derivation.eta (φt : Proposition L)
  exact (LK.Derivation.or (Γ := 0) (φ := ∃¹ ∼(φ : Semiproposition L 1))
    (ψ := (φt : Proposition L)) (LK.Derivation.cast (LK.Derivation.exs
      (Γ := ⦃(φt : Proposition L)⦄) (φ := ∼(φ : Semiproposition L 1))
      (t := Rew.emb t) d) (by simp [add_comm]))).cast (by simp [Semiformula.imp_eq, φt])

open Classical in
instance : Entailment.Deduction (Theory L) where
  ofInsert {φ ψ T} := fun ⟨b⟩ ↦ by
    let Γ := b.axioms.filter (· ≠ φ)
    refine ⟨Γ, ?_, ?_⟩
    · intro χ hχ
      rcases Multiset.mem_filter.mp hχ with ⟨hχ, hnχ⟩
      simpa [hnχ] using b.axioms_mem χ hχ
    · exact LK.Derivation.cast (LK.Derivation.or (Γ := (∼Γ).map Rewriting.emb)
        (φ := Rewriting.emb (∼φ)) (ψ := Rewriting.emb ψ)
        (contra (L := L) b.derivation
          (Γ := (∼Γ).map Rewriting.emb +
            ⦃Rewriting.emb (∼φ), Rewriting.emb ψ⦄)
          (default : ((∼Γ).map Rewriting.emb +
            ⦃Rewriting.emb (∼φ), Rewriting.emb ψ⦄).Traversal)
          (by simpa [OneSidedLK.Pullback, Multiset.tilde_def, Γ, add_assoc] using
            Multiset.map_subset_map (f := Rewriting.emb) <|
              Multiset.add_map_subset_map_filter_add_atom
                (s := b.axioms) (t := ⦃ψ⦄) (f := fun χ ↦ ∼χ) (a := φ))))
        (by simp [Multiset.tilde_def, Semiformula.imp_eq, add_comm])
  inv {φ ψ T} b :=
    Entailment.mdp (Entailment.Axiomatized.weakening (by simp) b)
      (Entailment.Axiomatized.by_axm (by simp))

end Theory.Proof

/-! ### Theory -/

namespace Theory

variable {U S : Theory L}

lemma weakerThan_union_right (h : U ⪯ S) (T : Theory L) : T ∪ U ⪯ T ∪ S :=
  Entailment.WeakerThan.ofAxm! <| by
    rintro φ (hφ | hφ);
    · exact Entailment.by_axm (Set.mem_union_left _ hφ);
    · exact Entailment.WeakerThan.pbl (h.pbl (Entailment.by_axm hφ));

lemma equiv_union_right (e : U ≊ S) (T : Theory L) : T ∪ U ≊ T ∪ S :=
  Entailment.Equiv.antisymm ⟨weakerThan_union_right e.le T, weakerThan_union_right e.symm.le T⟩

section compact

open Entailment

variable [L.DecidableEq] {T : Theory L} {φ : Sentence L}

lemma compact_add_right (h : T ∪ U ⊢ φ) :
    ∃ s : { s : Finset (Sentence L) // ↑s ⊆ U }, T ⊢ s.1.conj 🡒 φ := by
  obtain ⟨𝓕, h𝓕, hfin, hφ⟩ := Compact.finite_provable h;
  clear h;
  induction 𝓕, (Set.adjunctiveSet_finite_iff 𝓕).mp hfin using Set.Finite.induction_on
    generalizing φ with
  | empty => exact ⟨⟨∅, by simp⟩, C_of_conseq <| wk (by simp) hφ⟩;
  | @insert ψ S _ hS ih =>
    obtain ⟨⟨s, hs⟩, hsφ⟩ := ih (Set.insert_subset_iff.mp h𝓕).2 (by simpa using hS) (deduction hφ);
    rcases h𝓕 (Set.mem_insert ψ S) with hψ | hψ;
    · exact ⟨⟨s, hs⟩, C_swap hsφ ⨀ by_axm hψ⟩;
    · exact ⟨⟨insert ψ s, by simpa using Set.insert_subset hψ hs⟩,
        C_trans CinsertFConjKFConj <| CK_iff_CC.mpr <| C_swap hsφ⟩;

lemma compact_add_left (h : T ∪ U ⊢ φ) :
    ∃ s : { s : Finset (Sentence L) // ↑s ⊆ T }, U ⊢ s.1.conj 🡒 φ :=
  compact_add_right <| Set.union_comm T U ▸ h

end compact

end Theory

def Theory.theory (T : Theory L) : Theory L := {σ | T ⊢ σ}

@[simp] lemma Theory.mem_theory {T : Theory L} :
    σ ∈ T.theory ↔ T ⊢ σ := by simp [Theory.theory]

end FirstOrder

end FFL

end
