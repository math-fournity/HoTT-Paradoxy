module

public import Foundation.FirstOrder.Syntax.Classical.PrimrecCoding
public import Foundation.FirstOrder.Arithmetic.Bootstrapping.DerivabilityCondition.D1
public import Foundation.FirstOrder.Incompleteness.Church
public import Mathlib.Computability.Reduce
public import Mathlib.Data.Nat.Log

/-!
# Ehrenfeucht–Mycielski speedup theorem

`Theory.minProof T σ` is the least Gödel code of a proof `T ⊢₂! ↑σ`, and `0` when `σ` is not
`T`-provable.
-/

@[expose] public section

open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding

namespace FFL.FirstOrder.Arithmetic.Bootstrapping

section Provability

variable {L : Language} [inst : L.DecidableEq] {T : Theory L} {σ π : Sentence L}

omit inst in
lemma provable_insert_neg_iff_or : insert (∼σ) T ⊢ π ↔ T ⊢ σ ⋎ π :=
  Entailment.deduction_iff.trans
    ⟨fun h ↦ by classical cl_prover [h], fun h ↦ by classical cl_prover [h]⟩

end Provability

variable
  {L : Language} [L.DecidableEq] [L.Encodable] [L.LORDefinable]
  {T : Theory L} [T.Δ₁] {σ : Sentence L}

noncomputable def _root_.FFL.FirstOrder.Theory.minProof
    (T : Theory L) [T.Δ₁] (σ : Sentence L) : ℕ :=
  sInf (Set.range fun d : T ⊢₂! (σ : Proposition L) ↦ (⌜d⌝ : ℕ))

@[grind →]
lemma proof_minProof (h : T ⊢ σ) : Proof T (T.minProof σ) ⌜σ⌝ := by
  obtain ⟨d, hd⟩ : T.minProof σ ∈ Set.range (fun d : T ⊢₂! (σ : Proposition L) ↦ (⌜d⌝ : ℕ)) :=
    Nat.sInf_mem ⟨_, Set.mem_range_self (provable_iff_derivable2.mp h).some⟩
  exact hd ▸ proof_of_quote_proof2 d

@[grind →]
lemma minProof_eq_zero_of_unprovable (h : T ⊬ σ) : T.minProof σ = 0 := by
  have : IsEmpty (T ⊢₂! (σ : Proposition L)) :=
    not_nonempty_iff.mp fun hd ↦ h (provable_iff_derivable2.mpr hd)
  simp [Theory.minProof, Set.range_eq_empty_iff.mpr this]

@[grind ←]
lemma minProof_le (d : T ⊢₂! (σ : Proposition L)) : T.minProof σ ≤ ⌜d⌝ :=
  Nat.sInf_le (Set.mem_range_self d)

open Encodable

variable {α : Type*} [Primcodable α] {F : α → Sentence L}

omit [L.DecidableEq] in
lemma computablePred_proof : ComputablePred fun p : ℕ × ℕ ↦ Proof T p.1 p.2 := by
  apply ComputablePred.computable_of_manyOneReducible (q := fun n : ℕ => Proof T (π₁ n) (π₂ n));
  · use (fun p => Nat.pair p.1 p.2);
    and_intros;
    · exact Primrec₂.natPair.to_comp;
    · simp [←nat_pair_eq];
  · apply computablePred_iff_delta1.mpr;
    definability;


omit [L.DecidableEq] in
private lemma definable_bddExists_proof :
    𝚫ᴬ₁-Predicate fun n : ℕ ↦ ∃ d ≤ π₁ n, Proof T d (π₂ n) :=
  (Bounding.HierarchySymbol.Definable.arithmetic_bexs_ble (ℌ := 𝚫ᴬ₁)
    (f := fun v : Fin 1 → ℕ ↦ π₁ (v 0))
    (P := fun v x ↦ Proof T x (π₂ (v 0))) (by simp) (by definability)).of_iff <| fun v ↦
      exists_congr fun d ↦ and_congr_left' (by simp only [Arithmetic.le_def]; omega)

omit [L.DecidableEq] in
lemma computablePred_bddExists_proof [L.Primcodable] (hF : Computable F) {bd : α → ℕ}
    (hbd : Computable bd) :
  ComputablePred fun a ↦ ∃ d ≤ bd a, Proof T d ⌜F a⌝ := by
  apply ComputablePred.computable_of_manyOneReducible
    (q := fun n : ℕ ↦ ∃ d ≤ π₁ n, Proof T d (π₂ n));
  · use fun a => Nat.pair (bd a) (encode (F a));
    and_intros;
    · exact Computable₂.comp Primrec₂.natPair.to_comp hbd (Computable.encode.comp hF);
    · simp [←nat_pair_eq, Sentence.quote_eq_encode_nat];
  · apply computablePred_iff_delta1.mpr;
    exact definable_bddExists_proof;

lemma computablePred_provable_of_minProof_le [L.Primcodable] (hF : Computable F) {bd : α → ℕ}
  (hbd : Computable bd) (hb : ∀ a, T ⊢ F a → T.minProof (F a) ≤ bd a) :
  ComputablePred fun a ↦ T ⊢ F a := by
  apply ComputablePred.of_eq (computablePred_bddExists_proof (T := T) hF hbd);
  intro a;
  have hp : ∀ d, Proof T d ⌜F a⌝ → T ⊢ F a := fun d hd ↦ provable_iff_provable.mp ⟨d, hd⟩;
  grind;

private def speedupProof (T : Theory L) (σ π : Sentence L) :
    insert σ T ⊢₂! ((σ ⋎ π : Sentence L)) :=
  LK2.Derivation.or (φ := σ) (ψ := π) (by simp) <|
    LK2.Derivation.axm σ (by simp) (by simp)

private lemma computable_quote_speedupProof [L.Primcodable] :
    Computable fun π ↦ (⌜speedupProof T σ π⌝ : ℕ) :=
  have hc : Computable₂ fun s p : ℕ ↦
      orIntro (insert (s ^⋎ p) ∅) s p (axm (insert s (insert p (insert (s ^⋎ p) ∅))) s) :=
    computable₂_iff_sigma1.mpr (by definability);
  (hc.comp (Computable.const ⌜σ⌝) Sentence.primrec_quote_natCast.to_comp).of_eq fun π ↦ by
    simp [speedupProof, LK2.Derivation.quote_or, LK2.Derivation.quote_axm, Sentence.quote_def];

private lemma minProof_or_le_speedupProof (π : Sentence L) :
  (insert σ T).minProof (σ ⋎ π) ≤ ⌜speedupProof T σ π⌝ := minProof_le (speedupProof T σ π)

/-- The Ehrenfeucht–Mycielski speedup theorem.

- [EM71] -/
theorem ehrenfeucht_mycielski_speedup [L.Primcodable]
    (hU : ¬ComputablePred (insert (∼σ) T).theory) (f : ℕ → ℕ) (hf : Computable f) :
    ∃ π : Sentence L, T ⊢ π ∧ f ((insert σ T).minProof π) < T.minProof π := by
  contrapose! hU;
  apply ComputablePred.of_eq ?_ (fun π ↦ provable_insert_neg_iff_or.symm);
  exact computablePred_provable_of_minProof_le
    (Semiformula.primrec₂_or.comp (Primrec.const σ) Primrec.id).to_comp
    ((Nat.computable_boundedMax hf).comp computable_quote_speedupProof)
    fun π hπ ↦ (hU (σ ⋎ π) hπ).trans (Nat.le_boundedMax (minProof_or_le_speedupProof π));

section Arithmetic

variable {T : ArithmeticTheory} [T.Δ₁] [𝗜𝚺₁ ⪯ T] {σ : ArithmeticSentence}

open FFL.Entailment in
theorem ehrenfeucht_mycielski_speedup_arithmetic (hσ : T ⊬ σ) (f : ℕ → ℕ) (hf : Computable f) :
  ∃ π : ArithmeticSentence, T ⊢ π ∧ f ((insert σ T).minProof π) < T.minProof π :=
  have : 𝗜𝚺₁ ⪯ (insert (∼σ) T) :=
    WeakerThan.trans ‹𝗜𝚺₁ ⪯ T› (Axiomatized.le_of_subset (Set.subset_insert _ T));
  have : Consistent (insert (∼σ) T) := unprovable_iff_consistent_adjoin.mp hσ;
  ehrenfeucht_mycielski_speedup uncomputable_theory_of_consistent f hf

example (hσ : T ⊬ σ) :
  ∃ π : ArithmeticSentence, T ⊢ π ∧ (insert σ T).minProof π < Nat.log 2 (T.minProof π) := by
  obtain ⟨π, hπ, hlt⟩ := ehrenfeucht_mycielski_speedup_arithmetic hσ (fun x ↦ 2 ^ (x + 1)) <|
    Primrec₂.unpaired'.1 Nat.Primrec.pow |>.comp (Primrec.const 2) Primrec.succ |>.to_comp;
  use π;
  and_intros;
  · exact hπ;
  · apply Nat.le_log_iff_pow_le (by grind) (by grind) |>.mpr;
    omega;

end Arithmetic

end FFL.FirstOrder.Arithmetic.Bootstrapping
