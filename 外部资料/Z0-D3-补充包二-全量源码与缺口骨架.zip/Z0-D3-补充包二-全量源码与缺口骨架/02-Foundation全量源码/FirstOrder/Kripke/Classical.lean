module

public import Foundation.FirstOrder.Kripke.Intuitionistic
public import Foundation.FirstOrder.LJ.GoedelGentzen

@[expose] public section
/-! # Weak forcing

Main reference: Jeremy Avigad, "Forcing in proof theory" [Avi04]
-/

namespace FFL.FirstOrder

variable {L : Language} [L.Relational]

namespace Kripke.Model

variable {ℙ : Type*} [Preorder ℙ] {Name : Type*} [Kripke.Model L ℙ Name]
variable {n : ℕ} {ξ : Type*}

def WeaklyForces (p : ℙ) (bv : Fin n → Name) (fv : ξ → Name) (φ : Semiformula L ξ n) : Prop :=
  Forces p bv fv φᴺ

scoped[FFL.FirstOrder.KripkeModel] notation:45 p " ⊩ᶜ[" bv "|" fv "] " φ:46 =>
  FFL.FirstOrder.Kripke.Model.WeaklyForces p bv fv φ

open scoped FFL.FirstOrder.KripkeModel

@[simp] lemma exists_le {α : Type*} [Preorder α] (a : α) : ∃ x, x ≤ a := ⟨a, by rfl⟩

namespace WeaklyForces

variable {p q r : ℙ} {bv : Fin n → Name} {fv : ξ → Name}

@[simp] lemma rel {k : ℕ} {R : L.Rel k} {t : Fin k → Semiterm L ξ n} :
    p ⊩ᶜ[bv|fv] Semiformula.rel R t ↔
      ∀ q ≤ p, ∃ r ≤ q, Rel r R fun i ↦ (t i).relationalVal bv fv := by simp [WeaklyForces]

@[simp] lemma nrel {k : ℕ} {R : L.Rel k} {t : Fin k → Semiterm L ξ n} :
    p ⊩ᶜ[bv|fv] Semiformula.nrel R t ↔
      ∀ q ≤ p, ¬Rel q R fun i ↦ (t i).relationalVal bv fv := by simp [WeaklyForces]

@[simp] lemma verum : p ⊩ᶜ[bv|fv] (⊤ : Semiformula L ξ n) := by simp [WeaklyForces]

@[simp] lemma falsum : ¬p ⊩ᶜ[bv|fv] (⊥ : Semiformula L ξ n) := by rintro ⟨⟩

@[simp] lemma and {φ ψ : Semiformula L ξ n} :
    p ⊩ᶜ[bv|fv] φ ⋏ ψ ↔ p ⊩ᶜ[bv|fv] φ ∧ p ⊩ᶜ[bv|fv] ψ := by simp [WeaklyForces]

@[simp] lemma or {φ ψ : Semiformula L ξ n} :
    p ⊩ᶜ[bv|fv] φ ⋎ ψ ↔ ∀ q ≤ p, ∃ r ≤ q, r ⊩ᶜ[bv|fv] φ ∨ r ⊩ᶜ[bv|fv] ψ := by
  suffices
      (∀ q ≤ p, (∃ r ≤ q, Forces r bv fv φᴺ) ∨ ∃ r ≤ q, Forces r bv fv ψᴺ) ↔
      ∀ q ≤ p, ∃ r ≤ q, Forces r bv fv φᴺ ∨ Forces r bv fv ψᴺ by
    simpa [WeaklyForces, -not_and, not_and_or]
  grind

@[simp] lemma all {φ : Semiformula L ξ (n + 1)} :
    p ⊩ᶜ[bv|fv] ∀¹ φ ↔ ∀ q ≤ p, ∀ x : q, q ⊩ᶜ[↑x :> bv|fv] φ := by simp [WeaklyForces]

@[simp] lemma all_of_constantDomain [ConstantDomain ℙ] {φ : Semiformula L ξ (n + 1)} :
    p ⊩ᶜ[bv|fv] ∀¹ φ ↔ ∀ x : Name, p ⊩ᶜ[x :> bv|fv] φ := by simp [WeaklyForces, -Forces.all]

lemma rew {n₁ n₂ : ℕ} {ξ₁ ξ₂ : Type*} {bv : Fin n₂ → Name} {fv : ξ₂ → Name}
    {ω : Rew L ξ₁ n₁ ξ₂ n₂} {φ : Semiformula L ξ₁ n₁} :
    p ⊩ᶜ[bv|fv] (ω ▹ φ) ↔
    p ⊩ᶜ[fun x ↦ (ω #x).relationalVal bv fv|fun x ↦ (ω &x).relationalVal bv fv] φ := by
  simp [WeaklyForces, ←Semiformula.rew_doubleNegation, Forces.rew]

@[simp] lemma emb {bv : Fin n → Name} {fv : ξ → Name} {φ : Semiformula L Empty n} :
    p ⊩ᶜ[bv|fv] (Rew.emb ▹ φ) ↔
    p ⊩ᶜ[bv|Empty.elim] φ := by simp [rew, Empty.eq_elim]

@[simp] lemma ex {φ : Semiformula L ξ (n + 1)} :
    p ⊩ᶜ[bv|fv] ∃¹ φ ↔ ∀ q ≤ p, ∃ r ≤ q, ∃ x : r, r ⊩ᶜ[↑x :> bv|fv] φ := by
  suffices
      (∀ q ≤ p, ∃ r ≤ q, ∃ x ∈ Domain r, ∃ s ≤ r, s ⊩ᶜ[x :> bv|fv] φ) ↔
      (∀ q ≤ p, ∃ r ≤ q, ∃ x ∈ Domain r, r ⊩ᶜ[x :> bv|fv] φ) by
    simpa [WeaklyForces]
  constructor
  · intro h q hqp
    rcases h q hqp with ⟨r, hrq, x, hx, s, hsr, H⟩
    exact ⟨s, le_trans hsr hrq, x, domain_antimonotone hsr hx, H⟩
  · intro h q hqp
    rcases h q hqp with ⟨r, hrq, x, hx, H⟩
    exact ⟨r, hrq, x, hx, r, by rfl, H⟩

@[simp] lemma ex_of_constantDomain [ConstantDomain ℙ] {φ : Semiformula L ξ (n + 1)} :
    p ⊩ᶜ[bv|fv] ∃¹ φ ↔ ∀ q ≤ p, ∃ r ≤ q, ∃ x : Name, r ⊩ᶜ[x :> bv|fv] φ := by simp

lemma monotone {φ : Semiformula L ξ n} :
    p ⊩ᶜ[bv|fv] φ → ∀ q ≤ p, q ⊩ᶜ[bv|fv] φ := fun h ↦ Forces.monotone h

lemma generic {p : ℙ} {n} {bv : Fin n → Name} {fv : ξ → Name} {φ : Semiformula L ξ n} :
    (∀ q ≤ p, ∃ r ≤ q, r ⊩ᶜ[bv|fv] φ) → p ⊩ᶜ[bv|fv] φ :=
  match φ with
  | .rel R v => by
    suffices
      (∀ q ≤ p, ∃ r ≤ q, ∀ q ≤ r, ∃ s ≤ q, Rel s R fun i ↦ (v i).relationalVal bv fv) →
      (∀ q ≤ p, ∃ r ≤ q, Rel r R fun i ↦ (v i).relationalVal bv fv) by simpa
    intro h q hqp
    rcases h q hqp with ⟨r, hrq, H⟩
    rcases H r (by rfl) with ⟨s, hsr, Hs⟩
    exact ⟨s, le_trans hsr hrq, Hs⟩
  | .nrel R v => by
    suffices
      (∀ q ≤ p, ∃ r ≤ q, ∀ s ≤ r, ¬Rel s R fun i ↦ (v i).relationalVal bv fv) →
      (∀ q ≤ p, ¬Rel q R fun i ↦ (v i).relationalVal bv fv) by simpa
    intro h q hqp hR
    rcases h q hqp with ⟨r, hrq, Hr⟩
    exact Hr r (by rfl) (rel_monotone hR r hrq)
  | ⊤ => by simp
  | ⊥ => by simp
  | φ ⋏ ψ => by
    suffices
      (∀ q ≤ p, ∃ r ≤ q, r ⊩ᶜ[bv|fv] φ ∧ r ⊩ᶜ[bv|fv] ψ) → p ⊩ᶜ[bv|fv] φ ∧ p ⊩ᶜ[bv|fv] ψ by simpa
    intro h
    refine ⟨generic fun q hqp ↦ ?_, generic fun q hqp ↦ ?_⟩
    · rcases h q hqp with ⟨r, hrq, h, _⟩
      exact ⟨r, hrq, h⟩
    · rcases h q hqp with ⟨r, hrq, _, h⟩
      exact ⟨r, hrq, h⟩
  | φ ⋎ ψ => by
    suffices
      (∀ q ≤ p, ∃ r ≤ q, ∀ q ≤ r, ∃ r ≤ q, r ⊩ᶜ[bv|fv] φ ∨ r ⊩ᶜ[bv|fv] ψ) →
      (∀ q ≤ p, ∃ r ≤ q, r ⊩ᶜ[bv|fv] φ ∨ r ⊩ᶜ[bv|fv] ψ) by simpa
    intro h q hqp
    rcases h q hqp with ⟨r, hrq, H⟩
    rcases H r (by rfl) with ⟨s, hsr, Hs⟩
    exact ⟨s, le_trans hsr hrq, Hs⟩
  | ∀¹ φ => by
    suffices
      (∀ q ≤ p, ∃ r ≤ q, ∀ q ≤ r, ∀ a ∈ Domain q, q ⊩ᶜ[a :> bv|fv] φ) →
      (∀ q ≤ p, ∀ x ∈ Domain q, q ⊩ᶜ[x :> bv|fv] φ) by simpa
    intro h q hqp x hx
    apply generic
    intro r hrq
    rcases h r (le_trans hrq hqp) with ⟨s, hsr, Hs⟩
    exact ⟨s, hsr, Hs s (by rfl) x (domain_monotone hx _ (le_trans hsr hrq))⟩
  | ∃¹ φ => by
    suffices
      (∀ q ≤ p, ∃ r ≤ q, ∀ q ≤ r, ∃ r ≤ q, ∃ x ∈ Domain r, r ⊩ᶜ[x :> bv|fv] φ) →
      (∀ q ≤ p, ∃ r ≤ q, ∃ x ∈ Domain r, r ⊩ᶜ[x :> bv|fv] φ) by simpa
    intro h q hqp
    rcases h q hqp with ⟨r, hrq, H⟩
    rcases H r (by rfl) with ⟨s, hsr, x, hx, H⟩
    exact ⟨s, le_trans hsr hrq, x, hx, H⟩

lemma generic_iff {φ : Semiformula L ξ n} :
    p ⊩ᶜ[bv|fv] φ ↔ ∀ q ≤ p, ∃ r ≤ q, r ⊩ᶜ[bv|fv] φ :=
  ⟨fun H q hqp ↦ ⟨q, by rfl, H.monotone q hqp⟩, generic⟩

lemma generic_iff_not {φ : Semiformula L ξ n} :
    ¬p ⊩ᶜ[bv|fv] φ ↔ ∃ q ≤ p, ∀ r ≤ q, ¬r ⊩ᶜ[bv|fv] φ := by simpa using generic_iff.not

@[simp] lemma not {p : ℙ} {n} {bv : Fin n → Name} {fv : ξ → Name} {φ : Semiformula L ξ n} :
    p ⊩ᶜ[bv|fv] ∼φ ↔ ∀ q ≤ p, ¬q ⊩ᶜ[bv|fv] φ :=
  match φ with
  | .rel R v => by
    suffices
      (∀ q ≤ p, ¬Rel q R fun i ↦ (v i).relationalVal bv fv) ↔
      (∀ q ≤ p, ∃ r ≤ q, ∀ s ≤ r, ¬Rel s R fun i ↦ (v i).relationalVal bv fv) by simpa
    constructor
    · intro h q hqp
      exact ⟨q, by rfl, fun r hrq ↦ h r (le_trans hrq hqp)⟩
    · intro h q hqp H
      rcases h q hqp with ⟨r, hrq, Hr⟩
      exact Hr r (by rfl) (rel_monotone H _ hrq)
  | .nrel R v => by simp
  | ⊤ => by simp
  | ⊥ => by simp
  | φ ⋏ ψ => by
    suffices
        (∀ q ≤ p, ∃ r ≤ q, r ⊩ᶜ[bv|fv] ∼φ ∨ r ⊩ᶜ[bv|fv] ∼ψ) ↔
        (∀ q ≤ p, ¬q ⊩ᶜ[bv|fv] φ ∨ ¬q ⊩ᶜ[bv|fv] ψ) by
      simpa [-not_and, not_and_or]
    constructor
    · intro h q hqp
      rcases h q hqp with ⟨r, hrq, (H | H)⟩
      · left; intro Hqφ
        exact WeaklyForces.not.mp H r (by rfl) (Hqφ.monotone _ hrq)
      · right; intro Hqψ
        exact WeaklyForces.not.mp H r (by rfl) (Hqψ.monotone _ hrq)
    · intro h q hqp
      rcases h q hqp with (C | C)
      · rcases generic_iff_not.mp C with ⟨r, hrq, Hr⟩
        refine ⟨r, hrq, ?_⟩
        left; apply WeaklyForces.not.mpr Hr
      · rcases generic_iff_not.mp C with ⟨r, hrq, Hr⟩
        refine ⟨r, hrq, ?_⟩
        right; apply WeaklyForces.not.mpr Hr
  | φ ⋎ ψ => by
    suffices
      p ⊩ᶜ[bv|fv] ∼φ ∧ p ⊩ᶜ[bv|fv] ∼ψ ↔
      ∀ q ≤ p, ∃ r ≤ q, ∀ s ≤ r, ¬s ⊩ᶜ[bv|fv] φ ∧ ¬s ⊩ᶜ[bv|fv] ψ by simpa
    constructor
    · intro h q hqp
      refine ⟨q, by rfl, fun r hrq ↦ ⟨?_, ?_⟩⟩
      · exact WeaklyForces.not.mp h.1 r (le_trans hrq hqp)
      · exact WeaklyForces.not.mp h.2 r (le_trans hrq hqp)
    · intro h
      constructor
      · apply WeaklyForces.not.mpr
        intro q hqp Hq
        rcases h q hqp with ⟨r, hrq, H⟩
        exact (H r (by rfl)).1 (Hq.monotone _ hrq)
      · apply WeaklyForces.not.mpr
        intro q hqp Hq
        rcases h q hqp with ⟨r, hrq, H⟩
        exact (H r (by rfl)).2 (Hq.monotone _ hrq)
  | ∀¹ φ => by
    suffices
      (∀ q ≤ p, ∃ r ≤ q, ∃ a ∈ Domain r, r ⊩ᶜ[a :> bv|fv] ∼φ) ↔
      (∀ q ≤ p, ∃ r ≤ q, ∃ x ∈ Domain r, ¬r ⊩ᶜ[x :> bv|fv] φ) by simpa
    constructor
    · intro h q hqp
      rcases h q hqp with ⟨r, hrq, x, hx, Hr⟩
      exact ⟨r, hrq, x, hx, WeaklyForces.not.mp Hr r (by rfl)⟩
    · intro h q hqp
      rcases h q hqp with ⟨r, hrq, x, hx, H⟩
      rcases generic_iff_not.mp H with ⟨s, hsr, Hs⟩
      exact ⟨s, le_trans hsr hrq, x, domain_antimonotone hsr hx, WeaklyForces.not.mpr Hs⟩
  | ∃¹ φ => by
    suffices
      (∀ q ≤ p, ∀ a ∈ Domain q, q ⊩ᶜ[a :> bv|fv] ∼φ) ↔
      (∀ q ≤ p, ∃ r ≤ q, ∀ s ≤ r, ∀ x ∈ Domain s, ¬s ⊩ᶜ[x :> bv|fv] φ) by simpa
    constructor
    · intro h q hqp
      refine ⟨q, by rfl, ?_⟩
      intro r hrq x hx
      exact WeaklyForces.not.mp (h r (le_trans hrq hqp) x hx) r (by rfl)
    · intro h q hqp x hx
      apply WeaklyForces.not.mpr
      intro r hrq Hr
      rcases h r (le_trans hrq hqp) with ⟨s, hsr, H⟩
      have : ¬s ⊩ᶜ[x :> bv|fv] φ := H s (by rfl) x (domain_antimonotone (le_trans hsr hrq) hx)
      exact this (Hr.monotone _ hsr)

lemma generic_iff_not' {φ : Semiformula L ξ n} :
    ¬p ⊩ᶜ[bv|fv] φ ↔ ∃ q ≤ p, q ⊩ᶜ[bv|fv] ∼φ := by simpa using generic_iff.not

@[simp] lemma imply {φ ψ : Semiformula L ξ n} :
    p ⊩ᶜ[bv|fv] φ 🡒 ψ ↔ ∀ q ≤ p, q ⊩ᶜ[bv|fv] φ → q ⊩ᶜ[bv|fv] ψ := by
  suffices
    (∀ q ≤ p, ∃ r ≤ q, (∀ q ≤ r, ¬q ⊩ᶜ[bv|fv] φ) ∨ r ⊩ᶜ[bv|fv] ψ) ↔
    (∀ q ≤ p, q ⊩ᶜ[bv|fv] φ → q ⊩ᶜ[bv|fv] ψ) by simpa [LogicalConnective.DeMorgan.imply]
  constructor
  · intro h q hqp Hqφ
    by_contra! Hqψ
    rcases generic_iff_not.mp Hqψ with ⟨r, hrq, Hr⟩
    rcases h r (le_trans hrq hqp) with ⟨s, hsr, (H | H)⟩
    · exact H s (by rfl) (Hqφ.monotone s (le_trans hsr hrq))
    · exact Hr s hsr H
  · intro h q hqp
    have : ¬q ⊩ᶜ[bv|fv] φ ∨ q ⊩ᶜ[bv|fv] ψ := not_or_of_imp (h q hqp)
    rcases this with (H | H)
    · rcases generic_iff_not.mp H with ⟨r, hrq, H⟩
      exact ⟨r, hrq, Or.inl H⟩
    · exact ⟨q, by rfl, Or.inr H⟩

@[simp] lemma iff {φ ψ : Semiformula L ξ n} :
    p ⊩ᶜ[bv|fv] φ 🡘 ψ ↔ ∀ q ≤ p, q ⊩ᶜ[bv|fv] φ ↔ q ⊩ᶜ[bv|fv] ψ := by
  simp [LogicalConnective.iff]; grind

end WeaklyForces

abbrev WeaklyForces₀ (p : ℙ) (φ : Sentence L) : Prop := p ⊩ᶜ[![]|Empty.elim] ↑φ

instance : WeakForcingRelation ℙ (Sentence L) := ⟨WeaklyForces₀⟩

lemma weaklyForces₀_def {p : ℙ} {φ : Sentence L} : p ⊩ᶜ φ ↔ p ⊩ᶜ[![]|Empty.elim] φ := by rfl

lemma weaklyForces₀_iff_forces {p : ℙ} {φ : Sentence L} :
    p ⊩ᶜ φ ↔ p ⊩ φᴺ := by rfl

namespace WeaklyForces₀

variable {φ : Sentence L}

lemma monotone {p : ℙ} : p ⊩ᶜ φ → ∀ q ≤ p, q ⊩ᶜ φ := WeaklyForces.monotone

lemma generic {p : ℙ} :
    (∀ q ≤ p, ∃ r ≤ q, r ⊩ᶜ φ) → p ⊩ᶜ φ := WeaklyForces.generic

lemma generic_iff {p : ℙ} :
    p ⊩ᶜ φ ↔ ∀ q ≤ p, ∃ r ≤ q, r ⊩ᶜ φ := WeaklyForces.generic_iff

instance : WeakForcingRelation.ClassicalKripke ℙ (· ≥ ·) where
  verum w := by simp [weaklyForces₀_def]
  falsum w := by simp [weaklyForces₀_def]
  and w := by simp [weaklyForces₀_def]
  or w := by simp [weaklyForces₀_def]
  imply w := by simp [weaklyForces₀_def]
  not w := by simp [weaklyForces₀_def]
  monotone := monotone
  generic := generic

lemma sound [L.DecidableEq] :
    𝐋𝐊¹ ⊢ (φ : Proposition L) → ∀ p : ℙ, ∀ fv, (∀ i, p ⊩↓ fv i) →
      p ⊩ᶜ[![] | fv] φ := fun b p fv _ ↦ by
  have hfv : fv = Empty.elim := Subsingleton.elim _ _
  subst fv
  rcases Provable.gödel_gentzen (φ := (φ : Proposition L)) b with ⟨d⟩
  have hd := Kripke.Model.Forces.sound d p (fun _ ↦ (Classical.ofNonempty : p).val)
    (by simp) (by simp)
  simpa [WeaklyForces, ← Semiformula.rew_doubleNegation, Kripke.Model.Forces.rew,
    Empty.eq_elim] using hd

lemma sound₀ [L.DecidableEq] {σ : Sentence L} : 𝐋𝐊¹ ⊢ (σ : Proposition L) → ℙ ∀⊩ᶜ σ := fun b p ↦ by
  exact sound b p Empty.elim fun i ↦ i.elim

variable {T : Theory L} {σ : Sentence L}

open Classical in
/-- Weak forcing validates every consequence of a theory; a routine extension of pure soundness. -/
lemma sound_theory (h : T ⊢ σ) : ℙ ∀⊩ᶜ* T → ℙ ∀⊩ᶜ σ := by
  have sound_fin {S : Theory L} (hS : S.Finite) {σ : Sentence L}
      (hSσ : S ⊢ σ) : ℙ ∀⊩ᶜ* S → ℙ ∀⊩ᶜ σ := by
    induction S, hS using Set.Finite.induction_on generalizing σ with
    | empty => exact fun _ ↦ sound₀ (Theory.Proof.empty_provable_iff_eprovable.mp hSσ)
    | @insert ψ S hψ hS ih =>
      intro HS p
      have h₁ : S ⊢ ψ 🡒 σ := Entailment.deduction hSσ
      have h₂ : ℙ ∀⊩ᶜ ψ 🡒 σ := ih h₁ fun χ hχ ↦ HS χ (Set.mem_insert_of_mem ψ hχ)
      exact (WeaklyForces.imply.mp (h₂ p)) p le_rfl (HS ψ (Set.mem_insert ψ S) p)
  obtain ⟨S, hST, hS, hSσ⟩ := Entailment.Compact.finite_provable h
  intro H
  exact sound_fin (by simpa using hS) hSσ fun ψ hψ ↦ H ψ (hST hψ)

end WeaklyForces₀

end Kripke.Model

-- Inherits `Kripke.Mod`'s universe parameters, which only occur together for the same
-- intentional reason as there (`World`/`Carrier` need not share a universe).
set_option linter.checkUnivs false in
/-- Kripke model for classical first-order logic -/
def Kripke.ForcingNotion (L : Language) [L.Relational] := Kripke.Mod L

namespace Kripke.ForcingNotion

variable (ℙ : Kripke.ForcingNotion L)

@[coe] abbrev Condition := ℙ.World

abbrev Name := ℙ.Carrier

instance : CoeSort (Kripke.ForcingNotion L) (Type _) := ⟨fun ℙ ↦ ℙ.Condition⟩

instance : CoeSort ℙ (Type _) := ⟨fun p ↦ ℙ.Domain p⟩

instance : Nonempty ℙ := ℙ.nonempty

instance : Preorder ℙ := ℙ.preorder

instance kripke : Kripke.Model L ℙ ℙ.Name := Kripke.Mod.kripke ℙ

variable {ℙ}

open Kripke.Model
open scoped FFL.FirstOrder.KripkeModel

variable {φ : Sentence L}

instance : Semantics (Kripke.ForcingNotion L) (Sentence L) := ⟨fun ℙ φ ↦ ℙ ∀⊩ᶜ φ⟩

lemma models_def : ℙ ⊧ φ ↔ ℙ ∀⊩ᶜ φ := by rfl

lemma sound [L.DecidableEq] {σ : Sentence L} : 𝐋𝐊¹ ⊢ (σ : Proposition L) → ℙ ⊧ σ :=
  WeaklyForces₀.sound₀

instance [L.DecidableEq] (ℙ : Kripke.ForcingNotion L) :
    Sound (Entailment.pullback (𝐋𝐊¹ : LK L) ((↑·) : Sentence L → Proposition L)) ℙ :=
  ⟨fun {_} ↦ sound⟩

end Kripke.ForcingNotion

end FFL.FirstOrder
