module

public import Mathlib.Data.ENat.Basic


@[expose]
public section

namespace ENat

open scoped Classical in
noncomputable def find (P : ℕ → Prop) : ℕ∞ := if h : ∃ x : ℕ, P x then Nat.find h else ⊤

variable (P : ℕ → Prop)

theorem lt_find (n : ℕ) (h : ∀ m ≤ n, ¬P m) : (n : ℕ∞) < find P := by
  by_cases h : ∃ x : ℕ, P x
  · simpa [find, h, ENat.natCast_lt_natCast, Nat.lt_find_iff]
  · simp [find, h]

theorem exists_of_find_le (n : ℕ) (h : find P ≤ (n : ENat)) : ∃ m ≤ n, P m := by
  by_contra A
  exact Std.Irrefl.irrefl _ <| lt_of_le_of_lt h <| lt_find P n (by simpa using A)

lemma find_eq_top_iff : find P = ⊤ ↔ ∀ (n : ℕ), ¬P n := by simp [find]

lemma find_le (n : ℕ) (h : P n) : find P ≤ ↑n := by
  suffices ∃ m ≤ n, P m by
    simpa [show ∃ x, P x from ⟨n, h⟩, find, ENat.natCast_le_natCast, Nat.find_le_iff]
  exact ⟨n, by rfl, h⟩

end ENat

end
