# START：60 秒版

## 目标（一条 Lean 引理）

```lean
theorem zfcTr_D3_internalize {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]
    (τ : ArithmeticSentence)
    (h : Provable 𝗭𝗙𝗖 (⌜arithTrln.translate τ⌝ : V)) :
    Provable 𝗭𝗙𝗂 (⌜arithTrln.translate (zfcTr τ)⌝ : V)
```

读作：**ZFC 证明了 τ 的翻译，那么 ZFC 也能证明"ZFC 证明了 τ 的翻译"这句话的翻译。**
这是 Hilbert–Bernays 条件 D3 在显式谓词 `zfcTr` 下的形状（= 经翻译的形式化 Σ1 完全性）。

## 它为什么重要

`Z0Full.zfc_z0_full_of_D3_internalize`（已过核、无 sorry）以它为唯一显式前提给出完整形式：
`ZFC ⊬ arithTrln.translate (ZFC.consistent)`。引理一旦证明，Z0 的完整形式立即成立，不需要别的东西。

## 我实测到的新局面（这是本包的核心增量）

Foundation 在 `Arithmetic/Bootstrapping/DerivabilityCondition/D3.lean` 里证完了算术理论的 D3，
其产物是：

```lean
theorem sigma_one_complete {V} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁] {T} [T.Δ₁] [𝗣𝗔⁻ ⪯ T]
    {σ : ArithmeticSentence} (hσ : ℬ[<, ℒₒᵣ].Hierarchy 𝚺 1 σ)
    (h : V↓[ℒₒᵣ] ⊧ σ) : Provable T (⌜σ⌝ : V)
```

即 **"真 Σ1 句 → V 中存在推导编码"**，目标理论随便换。我本机实测：

- `Sh.RE`（C-119 已是 instance）⟹ Foundation 的 `Theory.craig` 实例 给出 `Sh.craig.Δ₁`；
- `𝗣𝗔⁻ ⪯ Sh.craig` 可合成；
- `Sh.craig ⪯ Sh` 与 `Sh ⪯ Sh.craig` 都可合成（故 `Sh.craig.standardProvability.HBL3` 由 `inferInstance` 直接得到）；
- 于是 `Bootstrapping.Arithmetic.sigma_one_complete (T := Sh.craig)` **可用**，我已写成 `Z0D3Skeleton.step1` 并编译通过：
  `V ⊧ zfcTr σ → Provable Sh.craig ⌜zfcTr σ⌝`。

## 缺口的精确形状（我的判断，与之前几个版本不同）

**不是**"需要从头证形式化 Σ1 完全性"。**是**"需要一条句法等价"：

```lean
-- [GAP] Z0D3Skeleton.gap
lemma keyE (σ : ArithmeticSentence) :
    𝗜𝚺₁ ⊢ zfcTr σ 🡘 provabilityPred Sh.craig σ
```

`zfcTr σ = trProv.val/[⌜σ⌝]`（Σ1 公式是 `∃y, iTDef y 0 x ∧ (provable 𝗭𝗙𝗖) y` 代入），
语义上等于 `Provable 𝗭𝗙𝗢 ⌜σᵗ⌝`；而 `provabilityPred Sh.craig σ = (provable Sh.craig)/[⌜σ⌝]`，
语义上等于 `Sh.craig ⊢ σ`。二者经 `Sh ⊢ σ ↔ 𝗭𝗙𝗂 ⊢ σᵗ` 语义等价，
但在 𝗜𝚺₁ 内部写成一句可证的等价式，还需要工作。

`keyE` 一旦成立，`zfcTr.HBL3` 由 `ProvabilityAbstraction.Provability.ext`
（`T ⊢ σ 🡘 τ → T₀ ⊢ 𝔅 σ 🡘 𝔅 τ`）从 Foundation 的 `provable_D3` 组合得到，
完整形式立即随之而来。

**最小替代路线（若 keyE 的 Iff 形式太难）**：只证单向蕴含
`𝗜𝚺₁ ⊢ zfcTr σ 🡒 provabilityPred Sh.craig σ`，配合 `Provability.mono'` 也能得到 D3 所需的一半；
见 `04-攻坚路线/ROUTES.md` §2。

## 验收（照 AGENTS.md 的 F-011 门禁）

1. 引理无 `sorry`、类型逐字不变；
2. `#print axioms` 只含 `propext`、`Classical.choice`、`Quot.sound`；
3. 24 个模块顺序编译 exit 0；
4. 若编译不了：照实写清楚卡在哪一条具体引理，**不要留 `sorry` 冒充完成**。
